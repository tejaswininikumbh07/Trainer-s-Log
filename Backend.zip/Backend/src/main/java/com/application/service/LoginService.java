package com.application.service;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;

import com.application.model.Login;
import com.application.model.Logs;
import com.application.model.Trainer;
import com.application.repository.LogRepository;
import com.application.repository.LoginRepository;
import com.application.repository.TrainerRepository;
@Service
public class LoginService {
	@Autowired
	private LoginRepository repo;
	
	@Autowired
	private LogRepository lr;
	
	@Autowired
	private TrainerRepository tr;

	public Login saveLogin(Login login) {
		// TODO Auto-generated method stub
		return repo.save(login);
	}

	public Login login(Login user) {
	    Login existingUser = repo.findById(user.getEmail()).orElse(null);
	    
	    if(existingUser != null && // Ensure existingUser is not null before accessing its properties
	            existingUser.getEmail().equals(user.getEmail()) &&
	            existingUser.getPass().equals(user.getPass()) &&
	            existingUser.getRole().equals(user.getRole())) {
	        System.out.println("Existing User Details:");
	        System.out.println("Email: " + existingUser.getEmail());
	        System.out.println("Password: " + existingUser.getPass());
	        System.out.println("Role: " + existingUser.getRole());
	        System.out.println("Name: " + existingUser.getUser());
	        return existingUser;
	    }
	    System.out.println("User Not Found");
	    return null;
	}
	
	public Login findLoginByEmail(String email) {
		Optional<Login> loginOptional = repo.findById(email);
	    
	    // Check if the login details exist for the given email
	    if (loginOptional.isPresent()) {
	        return loginOptional.get();
	    } else {
	        // Handle if login details are not found
	        return null;
	    }
	}
	
	

}
