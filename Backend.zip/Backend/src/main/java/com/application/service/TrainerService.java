package com.application.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;

import com.application.exception.ResourceNotFoundException;
import com.application.model.Login;
import com.application.model.Trainer;
import com.application.repository.LoginRepository;
import com.application.repository.TrainerRepository;
@Service
public class TrainerService {
	@Autowired
	private TrainerRepository repo;
	
	@Autowired
	private LoginRepository  LR;
	
    public Trainer findTrainerByEmail(String email) {
        return repo.findByEmail(email);
    }
	
	public Trainer saveTrainer(@NonNull Trainer trainer) {
		// TODO Auto-generated method stub
		return repo.save(trainer);
	}


	public Login saveLogin(Login login) {
		// TODO Auto-generated method stub
		return LR.save(login);
	}

	public Trainer findTrainerById(int id) {
		// TODO Auto-generated method stub
		return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Trainer not found with ID: " + id));
	}

	public List<Trainer> getAllTrainers() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	public void deleteTrainer(int id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
		
	}

	public Trainer findByEmail(String email) {
		// TODO Auto-generated method stub
		 return repo.findByEmail(email);
	}

}
