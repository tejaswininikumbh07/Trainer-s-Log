package com.application.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.exception.ResourceNotFoundException;
import com.application.model.Batch;
import com.application.repository.BatchRepository;
@Service
public class BatchService {
	@Autowired
	private BatchRepository batchrepo;
	public Batch createBatch(Batch batch) {
		// TODO Auto-generated method stub
		return batchrepo.save(batch);
	}
	public Batch saveBatch(Batch existingBatch) {
		// TODO Auto-generated method stub
		return batchrepo.save(existingBatch);
	}
	public Batch findBatchByID(int id) {
		// TODO Auto-generated method stub
		return batchrepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Trainer not found with ID: " + id));
	}
	public List<Batch> getAllBatches() {
		// TODO Auto-generated method stub
		return batchrepo.findAll();
	}
	public void deleteBatch(int id) {
		// TODO Auto-generated method stub
		batchrepo.deleteById(id);
		
	}

	public List<Batch> getStatsOfBatchWithTrainerName(String trainerName) {
        return batchrepo.findByTrainer(trainerName);
    }
	public List <Batch> findBatchByCode(String code) {
		// TODO Auto-generated method stub
		return batchrepo.findByCode(code);
	}
	public void deleteBatchById(int id) {
		batchrepo.deleteById(id);
    }

}
