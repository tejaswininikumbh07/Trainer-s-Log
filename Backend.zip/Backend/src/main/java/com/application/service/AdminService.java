package com.application.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;

import com.application.exception.ResourceNotFoundException;
import com.application.model.Admin;
import com.application.repository.AdminRepository;
@Service
public class AdminService {
	@Autowired
	private AdminRepository repo;

	public Admin saveAdmin(@NonNull Admin admin) {
		// TODO Auto-generated method stub
		return repo.save(admin);
	}

	public Admin findAdminById(int id) {
		// TODO Auto-generated method stub
		return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Trainer not found with ID: " + id));
	}
	public Admin findAdminByEmail(String email) {
        return repo.findByEmail(email);
    }
	public List<Admin> getAllAdmins() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	public void deleteAdmin(int id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
		
	}

}
