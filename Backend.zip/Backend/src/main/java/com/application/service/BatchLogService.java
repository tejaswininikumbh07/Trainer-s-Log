package com.application.service;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.application.model.BatchLogs;
import com.application.repository.BatchLogRepository;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BatchLogService {
	@Autowired
	private BatchLogRepository repo;
	public BatchLogs writeBatch(BatchLogs batch) {
		// TODO Auto-generated method stub
		return repo.save(batch);
	}
	

	public byte[] generateExcelFile() throws IOException {
	    List<BatchLogs> batchLogsList = repo.findAll();

	    try (Workbook workbook = new XSSFWorkbook()) {
	        Sheet sheet = workbook.createSheet("BatchLogs");
	        int rowNum = 0;

	        // Create font for the header
	        Font headerFont = workbook.createFont();
	        headerFont.setBold(true);

	        // Create cell style for the header
	        CellStyle headerCellStyle = workbook.createCellStyle();
	        headerCellStyle.setFont(headerFont);
	        headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
	        setBorder(headerCellStyle, BorderStyle.THIN);

	        // Create cell style for the data
	        CellStyle dataCellStyle = workbook.createCellStyle();
	        setBorder(dataCellStyle, BorderStyle.THIN);

	        // Add header row
	        Row headerRow = sheet.createRow(rowNum++);
	        String[] headerColumns = {"Batch Name", "Batch Code", "Trainer Name", "Date", "Topic", "Study Tools", "Homework", "Other Activities"};

	        // Set header columns
	        for (int i = 0; i < headerColumns.length; i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(headerColumns[i]);
	            cell.setCellStyle(headerCellStyle);
	            sheet.autoSizeColumn(i); // Set column width to auto
	        }

	        // Write data rows
	        for (BatchLogs batchLog : batchLogsList) {
	            Row row = sheet.createRow(rowNum++);

	            row.createCell(0).setCellValue(batchLog.getName());
	            row.createCell(1).setCellValue(batchLog.getCode());
	            row.createCell(2).setCellValue(batchLog.getTrainer());
	            row.createCell(3).setCellValue(batchLog.getDate().toString()); // Assuming Date is stored as java.util.Date
	            row.createCell(4).setCellValue(batchLog.getTopic());
	            row.createCell(5).setCellValue(batchLog.getStudytools());
	            row.createCell(6).setCellValue(batchLog.getHomework());
	            row.createCell(7).setCellValue(batchLog.getActivities());

	            // Apply data cell style with borders
	            for (int i = 0; i < headerColumns.length; i++) {
	                row.getCell(i).setCellStyle(dataCellStyle);
	            }
	        }

	        // Set column width manually (optional)
	        for (int i = 0; i < headerColumns.length; i++) {
	            sheet.setColumnWidth(i, 20 * 256); // Set column width in units of 1/256th of a character width
	        }

	        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	        workbook.write(outputStream);
	        return outputStream.toByteArray();
	    } catch (IOException e) {
	        // Handle IOException
	        e.printStackTrace();
	        return new byte[0]; // Or throw an exception
	    }
	}
	
	   public List<BatchLogs> getBatchLogsForBatchCodeAndDateRange(String batchCode, LocalDate fromDate, LocalDate toDate, String batchName) {
	        return repo.findByCodeAndNameAndDateBetween(batchCode, batchName, fromDate.minusDays(1), toDate.plusDays(1));
	    }

	   public byte[] generateExcelFileForBatch(List<BatchLogs> batchLogs) throws IOException {
		    try (Workbook workbook = new XSSFWorkbook()) {
		        Sheet sheet = workbook.createSheet("BatchLog");
		        int rowNum = 0;

		        // Create font for the header
		        Font headerFont = workbook.createFont();
		        headerFont.setBold(true);

		        // Create cell style for the header
		        CellStyle headerCellStyle = workbook.createCellStyle();
		        headerCellStyle.setFont(headerFont);
		        headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
		        setBorder(headerCellStyle, BorderStyle.THIN);

		        // Create cell style for the data
		        CellStyle dataCellStyle = workbook.createCellStyle();
		        setBorder(dataCellStyle, BorderStyle.THIN);

		        // Create cell style for the total duration row
		        CellStyle totalDurationCellStyle = workbook.createCellStyle();
		        totalDurationCellStyle.cloneStyleFrom(dataCellStyle);
		        totalDurationCellStyle.setAlignment(HorizontalAlignment.CENTER);

		        // Add header row
		        Row headerRow = sheet.createRow(rowNum++);
		        String[] headerColumns = {"SR no", "Date", "Batch Code", "Batch Name", "Start at", "Topic", "Study Tools Used", "Homework", "Other Activities", "Present Students", "Absent Students", "End at", "Duration"};

		        // Set header columns
		        for (int i = 0; i < headerColumns.length; i++) {
		            Cell cell = headerRow.createCell(i);
		            cell.setCellValue(headerColumns[i]);
		            cell.setCellStyle(headerCellStyle);
		            sheet.autoSizeColumn(i); // Set column width to auto
		        }

		        Duration totalDuration = Duration.ZERO;

		        // Write data rows
		        for (BatchLogs batchLog : batchLogs) {
		            Row row = sheet.createRow(rowNum++);

		            LocalTime startTime = batchLog.getStartTime();
		            LocalTime endTime = batchLog.getEndTime();
		            Duration duration = Duration.between(startTime, endTime);

		            totalDuration = totalDuration.plus(duration);

		            row.createCell(0).setCellValue(rowNum - 1); // SR no
		            row.createCell(1).setCellValue(batchLog.getDate().toString()); // Date
		            row.createCell(2).setCellValue(batchLog.getCode()); // Batch Code
		            row.createCell(3).setCellValue(batchLog.getName()); // Batch Name
		            row.createCell(4).setCellValue(startTime.format(DateTimeFormatter.ofPattern("HH:mm"))); // Start at
		            row.createCell(5).setCellValue(batchLog.getTopic()); // Topic
		            row.createCell(6).setCellValue(batchLog.getStudytools()); // Study Tools Used
		            row.createCell(7).setCellValue(batchLog.getHomework()); // Homework
		            row.createCell(8).setCellValue(batchLog.getActivities()); // Other Activities
		            row.createCell(9).setCellValue(batchLog.getPresents());
		            row.createCell(10).setCellValue(batchLog.getAbsents());
		            row.createCell(11).setCellValue(endTime.format(DateTimeFormatter.ofPattern("HH:mm"))); // End at
		            row.createCell(12).setCellValue(formatDuration(duration)); // Duration

		            // Apply data cell style with borders
		            for (int i = 0; i < headerColumns.length; i++) {
		                row.getCell(i).setCellStyle(dataCellStyle);
		            }
		        }

		        // Add total duration row
		        Row totalDurationRow = sheet.createRow(rowNum);
		        totalDurationRow.createCell(11).setCellValue("Total Duration:");
		        totalDurationRow.createCell(12).setCellValue(formatDuration(totalDuration));

		        // Apply cell style for total duration row
		        totalDurationRow.getCell(11).setCellStyle(headerCellStyle);
		        totalDurationRow.getCell(12).setCellStyle(totalDurationCellStyle);

		        // Set column width manually (optional)
		        for (int i = 0; i < headerColumns.length; i++) {
		            sheet.setColumnWidth(i, 20 * 256); // Set column width in units of 1/256th of a character width
		        }

		        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		        workbook.write(outputStream);
		        return outputStream.toByteArray();
		    }
		}


		// Helper method to format duration as "HH:mm:ss"
		private String formatDuration(Duration duration) {
		    long hours = duration.toHours();
		    long minutes = duration.minusHours(hours).toMinutes();
		    return String.format("%02d:%02d", hours, minutes);
		}

    private void setBorder(CellStyle style, BorderStyle borderStyle) {
        style.setBorderTop(borderStyle);
        style.setBorderRight(borderStyle);
        style.setBorderBottom(borderStyle);
        style.setBorderLeft(borderStyle);
    }
    
    public List<Object[]> findFieldsByTrainerAndDate(String trainerName, LocalDate date) {
        return repo.findFieldsByTrainerAndDate(trainerName, date);
    }


	public List<BatchLogs> getAllBatches() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
	
}
  
