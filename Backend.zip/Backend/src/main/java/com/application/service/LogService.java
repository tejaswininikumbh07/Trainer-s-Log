package com.application.service;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;

import com.application.model.Login;
import com.application.model.Logs;
import com.application.repository.LogRepository;
@Service
public class LogService {
	@Autowired
	private LogRepository logrepo;
	
	public Logs saveLog(Logs log) {
		// TODO Auto-generated method stub
		return logrepo.save(log);
		
	}



	   public Logs getLogsByTrainerName(String trainerName, Date today) {
	        return logrepo.findByTrainerNameAndLoginDate(trainerName, today);
	    }
	   
	   public byte[] generateExcelFileForTrainerAndDateRange(String trainerName, LocalDate startDate, LocalDate endDate) throws IOException {
		    List<Logs> logsList = logrepo.findByTrainerNameAndLoginDateBetween(trainerName, startDate, endDate);

		    if (logsList.isEmpty()) {
		        throw new IllegalArgumentException("No logs found for the given trainer name and date range");
		    }

		    try (Workbook workbook = new XSSFWorkbook()) { 
		        Sheet sheet = workbook.createSheet("Logs");
		        int rowNum = 0;

		        // Create font for the header
		        Font headerFont = workbook.createFont();
		        headerFont.setBold(true);

		        // Create cell style for the header
		        CellStyle headerCellStyle = workbook.createCellStyle();
		        headerCellStyle.setFont(headerFont);
		        headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
		        setBorder(headerCellStyle, BorderStyle.THIN);

		        // Create cell style for the data
		        CellStyle dataCellStyle = workbook.createCellStyle();
		        setBorder(dataCellStyle, BorderStyle.THIN);

		        // Add header row
		        Row headerRow = sheet.createRow(rowNum++);
		        String[] headerColumns = {"Sr", "Login Date", "Trainer Name", "Login Time", "Logout Time", "Working Hours"};

		        // Set header columns
		        for (int i = 0; i < headerColumns.length; i++) {
		            Cell cell = headerRow.createCell(i);
		            cell.setCellValue(headerColumns[i]);
		            cell.setCellStyle(headerCellStyle);
		            sheet.autoSizeColumn(i); // Set column width to auto
		        }

		        // Write data rows
		        int sr = 1;
		        long totalHours = 0;
		        long totalMinutes = 0;
		        for (Logs log : logsList) {
		            Row row = sheet.createRow(rowNum++);
		            
		            row.createCell(0).setCellValue(sr++);
		            row.createCell(1).setCellValue(log.getLoginDate().toString());
		            row.createCell(2).setCellValue(log.getTrainerName());
		            row.createCell(3).setCellValue(log.getLoginTime().toString());
		            row.createCell(4).setCellValue(log.getLogoutTime().toString());
		            String workingHours = calculateWorkingHours(log.getLoginTime(), log.getLogoutTime());
		            row.createCell(5).setCellValue(workingHours);
		            totalHours += Long.parseLong(workingHours.substring(0, 2));
		            totalMinutes += Long.parseLong(workingHours.substring(3));
		            
		            // Apply data cell style with borders
		            for (int i = 0; i < headerColumns.length; i++) {
		                row.getCell(i).setCellStyle(dataCellStyle);
		            }
		        }

		        // Calculate total working hours
		        long totalWorkingMinutes = totalHours * 60 + totalMinutes;
		        long totalWorkingHours = totalWorkingMinutes / 60;
		        long remainingMinutes = totalWorkingMinutes % 60;

		        // Add total row
		        Row totalRow = sheet.createRow(rowNum);
		        totalRow.createCell(4).setCellValue("Total Working Hours:");
		        totalRow.createCell(5).setCellValue(String.format("%02d:%02d", totalWorkingHours, remainingMinutes));

		        // Apply style for total row
		        totalRow.getCell(4).setCellStyle(headerCellStyle);
		        totalRow.getCell(5).setCellStyle(headerCellStyle);

		        // Set column width manually (optional)
		        for (int i = 0; i < headerColumns.length; i++) {
		            sheet.setColumnWidth(i, 20 * 256); // Set column width in units of 1/256th of a character width
		        }

		        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		        workbook.write(outputStream);
		        return outputStream.toByteArray();
		    } catch (IOException e) {
		        // Handle IOException
		        e.printStackTrace();
		        return new byte[0]; // Or throw an exception
		    }
		}

	    private void setBorder(CellStyle style, BorderStyle borderStyle) {
	        style.setBorderTop(borderStyle);
	        style.setBorderRight(borderStyle);
	        style.setBorderBottom(borderStyle);
	        style.setBorderLeft(borderStyle);
	    }

	    private String calculateWorkingHours(LocalTime loginTime, LocalTime logoutTime) {
	        Duration duration = Duration.between(loginTime, logoutTime);
	        long hours = duration.toHours();
	        long minutes = duration.minusHours(hours).toMinutes();
	        return String.format("%02d:%02d", hours, minutes);
	    }



		public List<Logs> getAllLogs() {
			// TODO Auto-generated method stub
			return logrepo.findAll();
		}



		public List<Logs> getLogsFormNameAndDateRange(String trainername, LocalDate fromDate, LocalDate toDate) {
			// TODO Auto-generated method stub
			List<Logs> logsList = logrepo.findByTrainerNameAndLoginDateBetween(trainername, fromDate, toDate);
			return  logsList;
		}
	    
	    
}
