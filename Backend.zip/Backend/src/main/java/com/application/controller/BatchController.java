package com.application.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.application.model.Batch;
import com.application.model.BatchLogs;
import com.application.service.BatchLogService;
import com.application.service.BatchService;

import lombok.RequiredArgsConstructor;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/batch")
public class BatchController {
	
	@Autowired
	private BatchService BS;
	
	@Autowired
	private BatchLogService BLS;
	
	 @PostMapping("/create")
	    public Batch createBatch(@RequestBody Batch batch) {
		 int f=batch.getFemales();
		 int m=batch.getMales();
		 int t=f+m;
		 	batch.setTotal(t);
	        return BS.createBatch(batch);
	    }
	 
	   @PutMapping("/update")
public Batch updateBatch(@RequestBody Batch updatedBatch) {
  // Retrieve the existing trainer from the database based on its ID
		   Batch existingBatch = BS.findBatchByID(updatedBatch.getId());
  
  // Update the fields of the existing trainer based on the provided updated trainer object
  switch (updatedBatch.getChoice()) {
      case "name":
    	  existingBatch.setName(updatedBatch.getName());
          break;
      case "trainer":
    	  existingBatch.setTrainer(updatedBatch.getTrainer());
          break;
      case "males":
    	  existingBatch.setTotal(existingBatch.getTotal() - existingBatch.getMales() + updatedBatch.getMales());
          existingBatch.setMales(updatedBatch.getMales());
          break;
      case "females":
    	  existingBatch.setTotal(existingBatch.getTotal() - existingBatch.getFemales() + updatedBatch.getFemales());
          existingBatch.setFemales(updatedBatch.getFemales());
          break;
      case "enddate":
    	  existingBatch.setEndDate(updatedBatch.getEndDate());
          break;
      case "status":
    	  existingBatch.setStatus(updatedBatch.getStatus());
          break;
      default:
          // Handle invalid field
          throw new IllegalArgumentException("Invalid field to update: " + existingBatch.getChoice());
  }
  
  return BS.saveBatch(existingBatch);
}
	   @GetMapping("/{id}")
	    public ResponseEntity<Batch> getBatchById(@PathVariable int id) {
	        Batch batch = BS.findBatchByID(id);
	        if (batch != null) {
	            return ResponseEntity.ok().body(batch);
	        } else {
	            return ResponseEntity.notFound().build();
	        }
	    }
	   
	   @GetMapping("find/{code}")
	   public ResponseEntity<List<Batch>> getBatchByCode(@PathVariable String code) {
	       List<Batch> batches = BS.findBatchByCode(code);
	       
	       if (batches != null && !batches.isEmpty()) {
	           for (Batch batch : batches) {
	               System.out.println("Batch: " + batch.getId() +" "+ batch.getName());
	           }
	           return ResponseEntity.ok().body(batches);
	       } else {
	           return ResponseEntity.notFound().build();
	       }
	   }


	    @GetMapping("/all")
	    public ResponseEntity<List<Batch>> getAllBatches() {
	        List<Batch> batches = BS.getAllBatches();
	        if (!batches.isEmpty()) {
	            return ResponseEntity.ok().body(batches);
	        } else {
	            return ResponseEntity.noContent().build();
	        }
	    }
	    
	    @DeleteMapping("/delete/{id}")
	    public ResponseEntity<String> deleteBatch(@PathVariable int id) {
	        BS.deleteBatchById(id);
	        return new ResponseEntity<>("Batch with ID: " + id + " deleted successfully.", HttpStatus.OK);
	    }
	    
	    @PostMapping("/write")
	    public BatchLogs writeBatch(@RequestBody BatchLogs batch) {
	    	batch.setDate(new Date());
	    	batch.setEndTime(LocalDateTime.now().toLocalTime());
	    	return BLS.writeBatch(batch);
		 
	    }
	    
	    @GetMapping(value = "/download", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	    public ResponseEntity<byte[]> downloadExcel() throws IOException {
	    	System.out.println("work");
	        byte[] excelContent = BLS.generateExcelFile();
	        return ResponseEntity.ok()
	                .header("Content-Disposition", "attachment; filename=batchlogs.xlsx")
	                .body(excelContent);
	    }
	    
	    @GetMapping("/download/{batchCode}/{batchName}")
	    public ResponseEntity<byte[]> downloadExcelForBatch(
	            @PathVariable String batchCode,
	            @PathVariable String batchName,
	            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
	            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate toDate) {

	        List<BatchLogs> batchLogs = BLS.getBatchLogsForBatchCodeAndDateRange(batchCode, fromDate, toDate, batchName);

	        if (!batchLogs.isEmpty()) {
	            try {
	                byte[] excelContent = BLS.generateExcelFileForBatch(batchLogs);
	                return ResponseEntity.ok()
	                        .header("Content-Disposition", "attachment; filename=${batchCode}_${batchName}_log_${fromDate}_${toDate}.xlsx")
	                        .contentType(MediaType.APPLICATION_OCTET_STREAM)
	                        .body(excelContent);
	            } catch (IOException e) {
	                e.printStackTrace();
	                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	            }
	        } else {
	            return ResponseEntity.noContent().build();
	        }
	    }
	    
	    @GetMapping("/view/{batchCode}/{batchName}")
	    public ResponseEntity<List<BatchLogs>> viewBatch(
	            @PathVariable String batchCode,
	            @PathVariable String batchName,
	            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
	            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate toDate) {

	        List<BatchLogs> batchLogs = BLS.getBatchLogsForBatchCodeAndDateRange(batchCode, fromDate, toDate, batchName);
	        return ResponseEntity.ok().body(batchLogs);
	    }
	    
	    @GetMapping("/view/all")
	    public ResponseEntity<List<BatchLogs>> getAllBatcheLog() {
	        List<BatchLogs> batches = BLS.getAllBatches();
	        if (!batches.isEmpty()) {
	            return ResponseEntity.ok().body(batches);
	        } else {
	            return ResponseEntity.noContent().build();
	        }
	    }
	    
	    @GetMapping("search/{trainerName}/{date}")
	    public List<Object[]> getBatchLogsFieldsByTrainerAndDate(
	            @PathVariable String trainerName,
	            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
	        
	        return BLS.findFieldsByTrainerAndDate(trainerName, date);
	    }
	    
	    @GetMapping("/stats/{trainerName}")
	    public List<Batch> getStatsOfBatchWithTrainerName(@PathVariable String trainerName) {
	        return BS.getStatsOfBatchWithTrainerName(trainerName);
	    }
	    
}
