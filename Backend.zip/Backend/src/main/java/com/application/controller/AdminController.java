package com.application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.application.model.Admin;
import com.application.model.Login;
import com.application.repository.AdminRepository;
import com.application.service.AdminService;
import com.application.service.LoginService;

import lombok.RequiredArgsConstructor;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {
	@Autowired
	private AdminService AS;
	
	@Autowired
	private LoginService LS;
	
	
	   @PostMapping("/create")
	   public Admin createAdmin (@RequestBody Admin admin) {
		   Login login = new Login();
		   login.setEmail(admin.getEmail());
		   login.setUser(admin.getName());
		   login.setPass(admin.getPass());
		    login.setRole("Admin");
		    LS.saveLogin(login);
		    return AS.saveAdmin(admin);
	   }
	   
	   @PutMapping("/update")
	    public Admin updateAdmin(@RequestBody Admin updatedAdmin) {
	        Admin existingAdmin = AS.findAdminById(updatedAdmin.getId());

	        if (existingAdmin != null) {
	            existingAdmin.setName(updatedAdmin.getName());
	            existingAdmin.setEmail(updatedAdmin.getEmail());
	            existingAdmin.setAddress(updatedAdmin.getAddress());
	            existingAdmin.setPhone(updatedAdmin.getPhone());
	            existingAdmin.setMedicalInfo(updatedAdmin.getMedicalInfo());
	            existingAdmin.setAge(updatedAdmin.getAge());
	            existingAdmin.setDesignation(updatedAdmin.getDesignation());
	            existingAdmin.setEducation(updatedAdmin.getEducation());
	            existingAdmin.setPass(updatedAdmin.getPass());
	            
	            Login login = LS.findLoginByEmail(updatedAdmin.getEmail());
	                if (login != null) {
	                    login.setEmail(updatedAdmin.getEmail());
	                    login.setPass(updatedAdmin.getPass());
	                    LS.saveLogin(login);
	                }

	            return AS.saveAdmin(existingAdmin);
	        } else {
	     
	            return null;
	        }
	    }
	   
	   @GetMapping("/{email}")
	   public ResponseEntity<Admin> getAdminByEmail(@PathVariable String email) {
	       Admin admin = AS.findAdminByEmail(email);
	       if (admin != null) {
	           return ResponseEntity.ok().body(admin);
	       } else {
	           return ResponseEntity.notFound().build();
	       }
	   }

	    @GetMapping("/list")
	    public ResponseEntity<List<Admin>> getAllAdmins() {
	        List<Admin> admins = AS.getAllAdmins();
	        if (!admins.isEmpty()) {
	            return ResponseEntity.ok().body(admins);
	        } else {
	            return ResponseEntity.noContent().build();
	        }
	    }
	    
	    @DeleteMapping("/{id}")
	    public ResponseEntity<String> deleteAdmin(@PathVariable int id) {
	        Admin admin = AS.findAdminById(id);
	        if (admin != null) {
	            AS.deleteAdmin(id);
	            return ResponseEntity.ok().body("Admin with ID " + id + " has been deleted successfully.");
	        } else {
	            return ResponseEntity.notFound().build();
	        }
	    }

}