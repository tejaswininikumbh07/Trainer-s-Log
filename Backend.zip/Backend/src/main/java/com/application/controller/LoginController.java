package com.application.controller;

import java.time.LocalTime;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.application.model.Login;
import com.application.model.Logs;
import com.application.model.Trainer;
import com.application.service.LogService;
import com.application.service.LoginService;
import com.application.service.TrainerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/")
public class LoginController {
    @Autowired
    private LoginService LS;

    @Autowired
    private LogService logService;

    @Autowired
    private TrainerService trainerService;

    @PostMapping("/login")
    public Login user(@RequestBody Login user) {
        if (user != null) {
        	System.out.println();
        	System.out.println("Given User Details:");
	        System.out.println("Email: " + user.getEmail());
	        System.out.println("Password: " + user.getPass());
	        System.out.println("Role: " + user.getRole());
            if ("Trainer".equals(user.getRole())) { // Compare strings using equals method, not ==
                Trainer trainer = trainerService.findTrainerByEmail(user.getEmail());
                if (trainer != null) {
                    Logs log = new Logs();
                    log.setLoginTime(LocalTime.now());
                    log.setLoginDate(new Date());
                    log.setTrainerName(trainer.getName());
                    logService.saveLog(log);
                }
            }
        }
        return LS.login(user);
    }
    
    @PostMapping("/logout")
    public void logout(@RequestBody Login user) {
        if (user != null) {
            if ("Trainer".equals(user.getRole())) {
                Trainer trainer = trainerService.findTrainerByEmail(user.getEmail());
                if (trainer != null) {
                    Date today = new Date();
                    Logs log = logService.getLogsByTrainerName(trainer.getName(), today);
                    if (log != null) {
                        // Update the logout time of the existing log entry
                        log.setLogoutTime(LocalTime.now());
                        // Save the updated log entry
                        logService.saveLog(log);
                    } else {
                        System.out.println("log not found");
                    }
                }
            }
        }
        // Assuming LS.login(user) is a method that handles login process.
        // If you intended to redirect to the login page, you don't need to return anything from a void method.
        LS.login(user); // This assumes LS is the service handling login operations.
    }



}
