package com.application.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.application.model.Admin;
import com.application.model.BatchLogs;
import com.application.model.Login;
import com.application.model.Logs;
import com.application.model.Trainer;
import com.application.repository.TrainerRepository;
import com.application.service.LogService;
import com.application.service.LoginService;
import com.application.service.TrainerService;

import lombok.RequiredArgsConstructor;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/trainer")
@RequiredArgsConstructor
public class TrainerController {
	
	@Autowired
	private TrainerService TS;
	
	@Autowired
	private LoginService LS;
	
	@Autowired
	private LogService Logservice;
	
	   @PostMapping("/create")
	   public Trainer createTrainer (@RequestBody Trainer trainer) {
		   Login login=new Login();
		   login.setEmail(trainer.getEmail());
		   login.setUser(trainer.getName());
		   login.setPass(trainer.getPass());
		    login.setRole("Trainer");
		    LS.saveLogin(login);
		    return TS.saveTrainer(trainer);
	   }
	   
	   @PutMapping("/update")
public Trainer updateTrainer(@RequestBody Trainer updatedTrainer) {
    // Retrieve the existing trainer from the database based on its ID
    Trainer existingTrainer = TS.findTrainerById(updatedTrainer.getId());
    //Login existingLogin = Logservice.findLogin(updatedTrainer.getId());
    
    // Update the fields of the existing trainer based on the provided updated trainer object
    switch (updatedTrainer.getChoice()) {
        case "name":
            existingTrainer.setName(updatedTrainer.getName());
            break;
        case "email":
            existingTrainer.setEmail(updatedTrainer.getEmail());
            if ("email".equals(updatedTrainer.getChoice())) {
                Login login = LS.findLoginByEmail(existingTrainer.getEmail());
                if (login != null) {
                    login.setEmail(updatedTrainer.getEmail());
                    LS.saveLogin(login);
                }
            }
            break;
        case "address":
            existingTrainer.setAddress(updatedTrainer.getAddress());
            break;
        case "phone":
            existingTrainer.setPhone(updatedTrainer.getPhone());
            break;
        case "dob":
            existingTrainer.setDob(updatedTrainer.getDob());
            break;
        case "age":
            existingTrainer.setAge(updatedTrainer.getAge());
            break;
        case "education":
            existingTrainer.setEducation(updatedTrainer.getEducation());
            break;
        case "batch":
            existingTrainer.setBatch(updatedTrainer.getBatch());
            break;
        case "pass":
        	existingTrainer.setPass(updatedTrainer.getPass());
            
            // Update the password in the login_details table
        	   if ("pass".equals(updatedTrainer.getChoice())) {
        	        Login login = LS.findLoginByEmail(existingTrainer.getEmail());
        	        if (login != null) {
        	            login.setPass(updatedTrainer.getPass());
        	            LS.saveLogin(login);
        	        }
        	    }
            break;
        case "city":
            existingTrainer.setCity(updatedTrainer.getCity());
            break;
        case "state":
            existingTrainer.setState(updatedTrainer.getState());
            break;
        case "country":
            existingTrainer.setCountry(updatedTrainer.getCountry());
            break;
        default:
            // Handle invalid field
            throw new IllegalArgumentException("Invalid field to update: " + updatedTrainer.getChoice());
    }
    
    return TS.saveTrainer(existingTrainer);
}
	   @GetMapping("/{id}")
	    public ResponseEntity<Trainer> getTrainerById(@PathVariable int id) {
	        Trainer trainer = TS.findTrainerById(id);
	        if (trainer != null) {
	            return ResponseEntity.ok().body(trainer);
	        } else {
	            return ResponseEntity.notFound().build();
	        }
	    }

	    @GetMapping("/all")
	    public ResponseEntity<List<Trainer>> getAllTrainers() {
	        List<Trainer> trainers = TS.getAllTrainers();
	        if (!trainers.isEmpty()) {
	            return ResponseEntity.ok().body(trainers);
	        } else {
	            return ResponseEntity.noContent().build();
	        }
	    }
	    
	    @GetMapping("/alllogs")
	    public ResponseEntity<List<Logs>> getAllLogs() {
	        List<Logs> logs = Logservice.getAllLogs();
	        if (!logs.isEmpty()) {
	            return ResponseEntity.ok().body(logs);
	        } else {
	            return ResponseEntity.noContent().build();
	        }
	    }
	    
	    @GetMapping("/search/{email}")
	    public ResponseEntity<Trainer> getTrainerByEmail(@PathVariable String email) {
	        Trainer trainer = TS.findByEmail(email);
	        if (trainer != null) {
	            return new ResponseEntity<>(trainer, HttpStatus.OK);
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }
	    
	    @DeleteMapping("/delete/{id}")
	    public ResponseEntity<String> deleteTrainer(@PathVariable int id) {
	        Trainer trainer = TS.findTrainerById(id);
	        if (trainer != null) {
	            TS.deleteTrainer(id);
	            return ResponseEntity.ok().body("Trainer with ID " + id + " has been deleted successfully.");
	        } else {
	            return ResponseEntity.notFound().build();
	        }
	    }
	    
	    @GetMapping("/export/{trainername}")
	    public ResponseEntity<byte[]> exportBatchLogsToExcel(
	            @PathVariable String trainername,
	            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
	            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate toDate) {
	        try {
	            byte[] excelContent = Logservice.generateExcelFileForTrainerAndDateRange(trainername, fromDate, toDate);

	            HttpHeaders headers = new HttpHeaders();
	            headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
	            headers.setContentDispositionFormData("attachment", "trainerlog.xlsx");
	            headers.setContentLength(excelContent.length);

	            return new ResponseEntity<>(excelContent, headers, HttpStatus.OK);
	        } catch (IOException e) {
	            e.printStackTrace();
	            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }
	    
	    @GetMapping("/log/{trainername}")
	    public ResponseEntity<List<Logs>> getLogs(
	            @PathVariable String trainername,
	            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
	            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate toDate) {

	        List<Logs> logs = Logservice.getLogsFormNameAndDateRange(trainername, fromDate, toDate);
	        return ResponseEntity.ok().body(logs);
	    }
}
