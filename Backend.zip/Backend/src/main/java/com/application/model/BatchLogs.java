package com.application.model;

import java.time.LocalTime;
import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Data
@Entity
@Table(name = "batchlogs")
public class BatchLogs {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name = "batch_name")
    private String name;
    
    @Column(name = "batch_code")
    private String code;
    
	@Column(name = "trainer_name")
    private String trainer;
	
	@Temporal(TemporalType.DATE)
    @Column(name = "date")
    private Date date;
    
    @Column(name = "topic_name")
    private String topic;
    
    @Column(name = "study_tools_used")
    private String studytools;
    
    @Column(name = "homework")
    private String homework;
    
    @Column(name = "other_activities")
    private String activities;
    
    @Column(name = "start_time")
    private LocalTime startTime;
    
    @Column(name = "students_present")
    private int presents;
    
    @Column(name = "students_absent")
    private int absents;
    
  //  @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "end_time")
    private LocalTime endTime;
    
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="batch_id" ,referencedColumnName = "id")
    private Batch batch;


	public BatchLogs() {
		super();
		// TODO Auto-generated constructor stub
	}


	public BatchLogs(int id, String name, String code, String trainer, Date date, String topic, String studytools,
			String homework, String activities, LocalTime startTime, LocalTime endTime, int absents, int presents) {
		super();
		this.id = id;
		this.name = name;
		this.code = code;
		this.trainer = trainer;
		this.date = date;
		this.topic = topic;
		this.studytools = studytools;
		this.homework = homework;
		this.activities = activities;
		this.startTime = startTime;
		this.endTime = endTime;
		this.presents = presents;
		this.absents = absents;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getTrainer() {
		return trainer;
	}


	public void setTrainer(String trainer) {
		this.trainer = trainer;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	public String getTopic() {
		return topic;
	}


	public void setTopic(String topic) {
		this.topic = topic;
	}


	public String getStudytools() {
		return studytools;
	}


	public void setStudytools(String studytools) {
		this.studytools = studytools;
	}


	public String getHomework() {
		return homework;
	}


	public void setHomework(String homework) {
		this.homework = homework;
	}


	public String getActivities() {
		return activities;
	}


	public void setActivities(String activities) {
		this.activities = activities;
	}


	public LocalTime getStartTime() {
		return startTime;
	}


	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}


	public LocalTime getEndTime() {
		return endTime;
	}


	public void setEndTime(LocalTime endTime) {
		this.endTime = endTime;
	}


	public int getPresents() {
		return presents;
	}


	public void setPresents(int presents) {
		this.presents = presents;
	}


	public int getAbsents() {
	    return absents;
	}

	public void setAbsents(int absents) {
	    this.absents = absents;
	}

	 
}
