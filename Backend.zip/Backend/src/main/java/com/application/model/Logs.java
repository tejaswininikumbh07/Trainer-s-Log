package com.application.model;

import java.time.LocalTime;
import java.util.Date;

import jakarta.persistence.*;
import lombok.Data;


@Data
@Entity
@Table(name = "logs")
public class Logs {
    
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

   // @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "login_time")
    private LocalTime loginTime;
    
  //  @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "logout_time")
    private LocalTime logoutTime;

    @Temporal(TemporalType.DATE)
    @Column(name = "login_date")
    private Date loginDate;

    @Column(name = "trainer_name")
    private String trainerName;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(referencedColumnName = "id")
    @Transient
    private Trainer trainer;

	public Logs() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Logs(int id, LocalTime loginTime, LocalTime logoutTime, Date loginDate, String trainerName) {
		super();
		this.id = id;
		this.loginTime = loginTime;
		this.logoutTime = logoutTime;
		this.loginDate = loginDate;
		this.trainerName = trainerName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalTime getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(LocalTime loginTime) {
		this.loginTime = loginTime;
	}

	public LocalTime getLogoutTime() {
		return logoutTime;
	}

	public void setLogoutTime(LocalTime logoutTime) {
		this.logoutTime = logoutTime;
	}

	public Date getLoginDate() {
		return loginDate;
	}

	public void setLoginDate(Date loginDate) {
		this.loginDate = loginDate;
	}

	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}
    
	    
}
