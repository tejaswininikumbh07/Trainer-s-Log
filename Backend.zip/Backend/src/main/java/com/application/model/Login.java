package com.application.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "login_details")
public class Login {
	@Id
	@Column(name = "email_id")
	private String email;
	@Column(name = "user_name")
	private String user;
	@Column(name = "password")
	private String pass;
	@Column(name = "role")
	private String role;
	
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Login(String email, String user, String pass, String role ) {
		super();
		this.email = email;
		this.user = user;
		this.pass = pass;
		this.role = role;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
}
