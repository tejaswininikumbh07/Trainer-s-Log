package com.application.model;

import java.util.Date;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "batch")
public class Batch {
		@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int id;
	    @Column(name = "batch_name")
	    private String name;
	    
	    @Column(name = "batch_code")
	    private String code;
	    
	    public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		public Batch(String code) {
			super();
			this.code = code;
		}

		@Column(name = "trainer_name")
	    private String trainer;
	    
	    @Column(name = "total_students")
	    private int total;
	    
	    @Column(name = "male_students")
	    private int males;
	    
	    @Column(name = "female_students")
	    private int females;
	    
	    @Column(name = "status")
	    private String status;
	    
	    @Temporal(TemporalType.DATE)
	    @Column(name = "start_date")
	    private Date startDate;
	    
	    @Temporal(TemporalType.DATE)
	    @Column(name = "end_date")
	    private Date endDate;
	    
	    @Transient
	    private String choice;
	    
	    @ManyToOne(cascade = CascadeType.ALL)
	    @JoinColumn(referencedColumnName = "id")
	    private Trainer batch_trainer;

		public Batch() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Batch(int id, String name, String trainer, int total, int males, int females, String choice, String status, Date startDate, Date endDate) {
			super();
			this.id = id;
			this.name = name;
			this.trainer = trainer;
			this.total = total;
			this.males = males;
			this.females = females;
			this.choice = choice;
			this.status = status;
			this.startDate = startDate;
			this.endDate = endDate;
		}
		

		public String getChoice() {
			return choice;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}
		
		public void setName(String name) {
			this.name = name;
		}

		public String getTrainer() {
			return trainer;
		}

		public void setTrainer(String trainer) {
			this.trainer = trainer;
		}

		public int getTotal() {
			return total;
		}

		public void setTotal(int total) {
			this.total = total;
		}

		public int getMales() {
			return males;
		}

		public void setMales(int males) {
			this.males = males;
		}

		public int getFemales() {
			return females;
		}

		public void setFemales(int females) {
			this.females = females;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public Date getStartDate() {
			return startDate;
		}

		public void setStartDate(Date startDate) {
			this.startDate = startDate;
		}

		public Date getEndDate() {
			return endDate;
		}

		public void setEndDate(Date endDate) {
			this.endDate = endDate;
		}
		
		
	    

}
