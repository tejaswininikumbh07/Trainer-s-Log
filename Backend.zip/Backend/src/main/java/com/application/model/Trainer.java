package com.application.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "trainer")
public class Trainer {
	
	public Trainer() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name="name")
    private String name;
    @Column(name="email")
    private String email;
    @Column(name="address")
    private String address;
    @Column(name="phone")
    private String phone;
    @Column(name="dob")
    private String dob;
    @Column(name="age")
    private int age;
    @Column(name="gender")
    private String gender;
    @Column(name="bloodgroup")
    private String bloodGroup;
    @Column(name="medicalinfo")
    private String medicalInfo;
    @Column(name="education")
    private String education;
    @Column(name="specification")
    private String specification;
    @Column(name="batch")
    private String batch;
    @Column(name = "password")
    private String pass;
    
    @Column(name = "city")
    private String city;
    
    @Column(name = "state")
    private String state;
    
    @Column(name = "country")
    private String country;
    
    
 
    
    @Transient
    private String choice;
    
    
	public Trainer(int id, String name, String email, String address, String phone, String dob, int age, String gender,
			String bloodGroup, String medicalInfo, String education, String specification, String batch, String pass, String choice, String city, String state, String country) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.address = address;
		this.phone = phone;
		this.dob = dob;
		this.age = age;
		this.gender = gender;
		this.bloodGroup = bloodGroup;
		this.medicalInfo = medicalInfo;
		this.education = education;
		this.specification = specification;
		this.batch = batch;
		this.pass = pass;
		this.choice = choice;
		this.city = city;
		this.state = state;
		this.country = country;
	}
	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getChoice() {
		return choice;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getMedicalInfo() {
		return medicalInfo;
	}
	public void setMedicalInfo(String medicalInfo) {
		this.medicalInfo = medicalInfo;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getSpecification() {
		return specification;
	}
	public void setSpecification(String specification) {
		this.specification = specification;
	}
	public String getBatch() {
		return batch;
	}
	public void setBatch(String batch) {
		this.batch = batch;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	
}
