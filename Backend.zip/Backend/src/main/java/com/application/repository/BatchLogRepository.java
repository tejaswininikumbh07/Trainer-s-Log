package com.application.repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.application.model.BatchLogs;

@Repository
public interface BatchLogRepository extends JpaRepository<BatchLogs, Integer>{
	List<BatchLogs> findByCodeAndNameAndDateBetween(String code, String name, LocalDate fromDate, LocalDate toDate);
	
	   @Query
	   ("SELECT b.code, b.name, b.topic, b.homework, b.presents, b.startTime, b.endTime " +
	           "FROM BatchLogs b " +
	           "WHERE b.trainer = ?1 AND b.date = ?2")
	    List<Object[]> findFieldsByTrainerAndDate(String trainerName, LocalDate date);

}