package com.application.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.application.model.Login;
import com.application.model.Trainer;
@Repository
public interface TrainerRepository extends JpaRepository<Trainer, Integer>{
	
	@Query("SELECT t FROM Trainer t WHERE t.email = :email")
    Trainer findByEmail(@Param("email") String email);

}
