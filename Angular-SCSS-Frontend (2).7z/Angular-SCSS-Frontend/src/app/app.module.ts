import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomePageComponent } from './Components/welcome-page/welcome-page.component';
import { LoginComponent } from './Account/login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BodyComponent } from './Components/body/body.component';
import { SidenavComponent } from './Components/sidenav/sidenav.component';
import { SublevelMenuComponent } from './Components/sidenav/sublevel-menu.component';
import { TrainerDashboardComponent } from './Components/Trainer/trainer-dashboard/trainer-dashboard.component';
import { AdminDashboardComponent } from './Components/Admin/admin-dashboard/admin-dashboard.component';
import { BatchComponent } from './Components/Trainer/batch/batch.component';
import { LogoutComponent } from './Account/logout/logout.component';
import { DatePipe } from '@angular/common';
import { TrainerProfileComponent } from './Components/Trainer/trainer-profile/trainer-profile.component';
import { InstagramComponent } from './Components/WebPages/instagram/instagram.component';
import { FacebookComponent } from './Components/WebPages/facebook/facebook.component';
import { LinkedinComponent } from './Components/WebPages/linkedin/linkedin.component';
import { GithubComponent } from './Components/WebPages/github/github.component';
import { GmailComponent } from './Components/WebPages/gmail/gmail.component';
import { AboutComponent } from './Components/WebPages/about/about.component';
@NgModule({
  declarations: [
    AppComponent,
    BodyComponent,
    SidenavComponent,
    SublevelMenuComponent,
    WelcomePageComponent,
    LoginComponent,
    TrainerDashboardComponent,
    AdminDashboardComponent,
    BatchComponent,
    LogoutComponent,
    TrainerProfileComponent,
    InstagramComponent,
    FacebookComponent,
    LinkedinComponent,
    GithubComponent,
    GmailComponent,
    AboutComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
