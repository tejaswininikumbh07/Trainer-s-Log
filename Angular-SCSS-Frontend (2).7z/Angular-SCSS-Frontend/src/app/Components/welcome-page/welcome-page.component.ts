import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NavDataService } from '../../Services/nav-data-service.service';

@Component({
  selector: 'app-welcome-page',
  templateUrl: './welcome-page.component.html',
  styleUrl: './welcome-page.component.scss'
})
export class WelcomePageComponent {
  constructor(private router: Router, private navDataService: NavDataService){
    this.navDataService.updateLoginNavData();

  }
login() {
this.router.navigate(['/login'])
}

}
