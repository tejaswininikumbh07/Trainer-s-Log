import { Component } from '@angular/core';

@Component({
  selector: 'app-gmail',
  templateUrl: './gmail.component.html',
  styleUrl: './gmail.component.scss'
})
export class GmailComponent {
  constructor(){
    window.location.href ='mailto:ssuyyog111@gmail.com';
  }

}
