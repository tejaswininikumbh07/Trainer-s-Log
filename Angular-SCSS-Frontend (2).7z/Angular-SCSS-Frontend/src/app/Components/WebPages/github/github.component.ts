import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-github',
  templateUrl: './github.component.html',
  styleUrl: './github.component.scss'
})
export class GithubComponent implements OnInit{
  constructor(private router: Router){
    // this.router.navigateByUrl("https://github.com/Suyog-0111");
    window.location.href = "https://github.com/Suyog-0111";
  }
  ngOnInit(): void {
    //this.router.navigateByUrl("https://github.com/Suyog-0111");
  }
}
