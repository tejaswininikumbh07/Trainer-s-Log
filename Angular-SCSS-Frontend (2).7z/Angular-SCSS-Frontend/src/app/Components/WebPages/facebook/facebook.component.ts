import { Component } from '@angular/core';

@Component({
  selector: 'app-facebook',
  templateUrl: './facebook.component.html',
  styleUrl: './facebook.component.scss'
})
export class FacebookComponent {
  constructor(){
    window.location.href = 'https://www.facebook.com/profile.php?id=100080110899706&mibextid=ZbWKwL'
  }

}
