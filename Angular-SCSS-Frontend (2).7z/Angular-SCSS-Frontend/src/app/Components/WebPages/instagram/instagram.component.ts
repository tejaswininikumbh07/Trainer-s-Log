import { Component } from '@angular/core';

@Component({
  selector: 'app-instagram',
  templateUrl: './instagram.component.html',
  styleUrl: './instagram.component.scss'
})
export class InstagramComponent {
  constructor(){
    window.location.href = 'https://www.instagram.com/deshpande_yogesh_d?igsh=MW4xYTkwNG9sdjg3eA==';
  }

}
