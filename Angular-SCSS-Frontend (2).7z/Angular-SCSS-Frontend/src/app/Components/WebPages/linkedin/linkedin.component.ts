import { Component } from '@angular/core';

@Component({
  selector: 'app-linkedin',
  templateUrl: './linkedin.component.html',
  styleUrl: './linkedin.component.scss'
})
export class LinkedinComponent {
  constructor(){
    window.location.href = 'https://in.linkedin.com/in/suyog-awate-15494123b?trk=public_profile_samename-profile';
  }

}
