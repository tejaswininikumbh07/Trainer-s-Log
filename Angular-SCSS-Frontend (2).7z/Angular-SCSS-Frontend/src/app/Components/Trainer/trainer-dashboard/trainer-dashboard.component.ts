import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { User } from '../../../Model/user';
import { Trainer } from '../../../Model/trainer';
import { Calendar } from '../../../Model/calendar';
import { BackEndService } from '../../../Services/back-end.service';
import { NavDataService } from '../../../Services/nav-data-service.service';
import { Router } from '@angular/router';
import { waitForAsync } from '@angular/core/testing';

@Component({
  selector: 'app-trainer-dashboard',
  templateUrl: './trainer-dashboard.component.html',
  styleUrl: './trainer-dashboard.component.scss'
})
export class TrainerDashboardComponent implements OnInit{
  
  calendarDays: { day: number; isPrevDate: boolean; isNextDate: boolean }[][] = [];
  activeDay: number = 0;
  dateInput: string = '';
  month: number = 0;
  year: number = 0;
  day: string = '';
  months: string[] = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  currentDate: Date = new Date(); // Current date
  currentHour: number = this.currentDate.getHours(); // Current hour
  currentTime: string = this.datePipe.transform(this.currentDate, 'shortTime') ?? ''; // Current time
  activeToday: any;
  batchSchedules: Calendar[] = [];
  user:User = new User;
  trainer: Trainer = new Trainer();
  trainerName= this.user.name;
  trainerEmail = this.user.email;

  constructor(
    private datePipe: DatePipe,
    private service: BackEndService,
    private navDataService: NavDataService,
    private router: Router
  ) {
    this.navDataService.updateTrainerNavData();
    const userData = sessionStorage.getItem('currentUser');
    
    if (userData !== null) {
      this.user = JSON.parse(userData);
      console.log(userData);
      
      this.getTrainer(this.user.email as string);
      
      setTimeout(() => {
        this.initCalendar();
      }, 150); // Delay of 5000 milliseconds (5 seconds)
    }
  }
  
  
  ngOnInit(): void {
    // this.navDataService.updateTrainerNavData();
    // this.initCalendar()
    const userData = sessionStorage.getItem('currentUser');
    
    if (userData !== null) {
      this.user = JSON.parse(userData);
      console.log(userData);
      
      this.getTrainer(this.user.email as string);
      setTimeout(() => {
        this.initCalendar();
      }, 200); // Delay of 5000 milliseconds (5 seconds)
    }
    setInterval(() => {
      this.currentDate = new Date();
      this.currentHour = this.currentDate.getHours();
      this.currentTime = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
    }, 1000);
    

    
  }

  initCalendar() {
    const today = new Date();
    this.activeDay = today.getDate();
    this.month = today.getMonth();
    this.year = today.getFullYear();
    this.generateCalendar(this.year, this.month);
    this.dateInput = '';
    const formattedDate = this.datePipe.transform(today, 'yyyy-MM-dd') ?? '';
  this.getBatchSchedule(formattedDate);
  }

  navigateToProfile() {
    this.router.navigate(['/myprofile']);
    }

  generateCalendar(year: number, month: number) {
    this.calendarDays = [];

    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);

    let currentDate = new Date(firstDayOfMonth);
    let currentWeek: { day: number; isPrevDate: boolean; isNextDate: boolean }[] = [];

    // Fill in preceding days from previous month
    for (let i = 1; i < firstDayOfMonth.getDay(); i++) {
      const prevDate = new Date(firstDayOfMonth);
      prevDate.setDate(prevDate.getDate() - firstDayOfMonth.getDay() + i);
      currentWeek.push({ day: prevDate.getDate(), isPrevDate: true, isNextDate: false });
    }

    while (currentDate <= lastDayOfMonth) {
      if (currentWeek.length === 7) {
        this.calendarDays.push(currentWeek);
        currentWeek = [];
      }

      currentWeek.push({ day: currentDate.getDate(), isPrevDate: false, isNextDate: false });
      currentDate.setDate(currentDate.getDate() + 1);
    }

    // Fill in remaining days from next month
    while (currentWeek.length < 7) {
      const day = currentDate.getDate();
      currentWeek.push({ day, isPrevDate: false, isNextDate: true });
      currentDate.setDate(day + 1);
    }

    this.calendarDays.push(currentWeek);

    // Update activeToday after generating the calendar
    this.updateActiveToday(this.activeDay);
  }

  changeMonth(offset: number) {
    this.month += offset;
    if (this.month < 0) {
      this.month = 11;
      this.year -= 1;
    } else if (this.month > 11) {
      this.month = 0;
      this.year += 1;
    }
    this.generateCalendar(this.year, this.month);
  }

  goToToday() {
    this.initCalendar();
  }

  goToDate() {
    if (this.dateInput) {
      const [day, month, year] = this.dateInput.split('/');
      const parsedDay = parseInt(day);
      const parsedMonth = parseInt(month) - 1; // Subtract 1 as months are zero-indexed
      const parsedYear = parseInt(year);
    
      // Check if all parts are valid integers
      if (!isNaN(parsedDay) && !isNaN(parsedMonth) && !isNaN(parsedYear)) {
        // Check if parsed date is a valid date
        const parsedDate = new Date(parsedYear, parsedMonth, parsedDay);
        if (!isNaN(parsedDate.getTime())) { // getTime() returns NaN if the date is invalid
          // Date is valid, update calendar
          this.month = parsedMonth;
          this.year = parsedYear;
          this.activeDay = parsedDay; // Update the activeDay property
          this.generateCalendar(this.year, this.month); // Pass year and month only
          const formattedDate = this.datePipe.transform(parsedDate, 'yyyy-MM-dd') ?? '';
          this.getBatchSchedule(formattedDate);
          return;
        }
      }
    }
    
    // Handle invalid input
    console.error('Invalid date input:', this.dateInput);
  }
  
   

  updateEvents(day: number) {
    if (!isNaN(day) && day > 0) {
      this.activeDay = day;
      this.updateActiveToday(day);
      const formattedDate = this.datePipe.transform(new Date(this.year, this.month, day), 'yyyy-MM-dd') ?? '';
      if (formattedDate) {
        this.getBatchSchedule(formattedDate);
      }
    }
  }
  
  private getTrainer(trainerEmail:string){
    // this.Service.getTrainer this.employee = new Employee();
    this.service.getTrainer(trainerEmail).subscribe( data => {
      this.trainer = data;
      console.log(this.trainer)
      this.trainerName =this.trainer.name;
    });
  }

  getActiveDateBatchSchedule(day: number) {
    if (!isNaN(day) && day > 0) {
      const selectedDate = new Date(this.year, this.month, day);
      const formattedDate = this.datePipe.transform(selectedDate, 'yyyy-MM-dd') ?? '';
      if (formattedDate) {
        this.getBatchSchedule(formattedDate);
      }
    }
  }
  

  private getBatchSchedule(date: string) {
    this.service.getBatchSchedule(date, this.trainerName).subscribe((data: any[]) => {
      this.batchSchedules = data.map(item => ({
        batchCode: item[0],
        batchName: item[1],
        topic: item[2],
        homework: item[3],
        presentStudents: item[4],
        startTime: this.formatTime(item[5]), // Format start time
        endTime: this.formatTime(item[6])    // Format end time
      }));
      console.log("Batch Schedules:", this.batchSchedules);
    }, error => {
      console.error("Error fetching batch schedules:", error);
    });
  }
  
  // Function to format time as HH:MM
  private formatTime(timeString: string | null): string {
    if (timeString) {
      const [hours, minutes, seconds] = timeString.split(':');
      return `${hours}:${minutes}`;
    } else {
      // Handle the case where timeString is null
      return ''; // Or any default value you prefer
    }
  }
  


  addListeners() {
    document.addEventListener('keydown', (event) => {
      if (event.key === 'ArrowLeft') {
        this.changeMonth(-1);
      } else if (event.key === 'ArrowRight') {
        this.changeMonth(1);
      }
    });
  }

  private updateActiveToday(day: number) {
    const newDate = new Date(this.year, this.month, day);
    this.activeToday = this.datePipe.transform(newDate, 'EEEE');
  }
}
