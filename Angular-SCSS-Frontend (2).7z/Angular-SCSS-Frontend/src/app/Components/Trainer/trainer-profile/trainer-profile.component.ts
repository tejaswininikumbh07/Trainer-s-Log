import { Component, OnInit } from '@angular/core';
import { BackEndService } from '../../../Services/back-end.service';
import { DatePipe } from '@angular/common';
import { Batch } from '../../../Model/batch';
import { Trainer } from '../../../Model/trainer';
import { NavDataService } from '../../../Services/nav-data-service.service';

@Component({
  selector: 'app-trainer-profile',
  templateUrl: './trainer-profile.component.html',
  styleUrl: './trainer-profile.component.scss'
})
export class TrainerProfileComponent implements OnInit {
  trainer: Trainer | undefined;
  trainerName: any;
  trainerEmail: any;
  academyEmail = "sda@sspu.ac.in";
  fName: string | undefined;
  lName: string | undefined;
  dobFormatted: any | undefined; // Add a property to store formatted DOB
  active: any;
  comp: any;
  total: any;
  assign: any;
  batch: Batch[] =[];
  

  constructor(private service: BackEndService, private datePipe: DatePipe, private navDataService: NavDataService) {
    this.navDataService.updateTrainerNavData(); } // Inject DatePipe

  ngOnInit() {
    const currentUserJson = sessionStorage.getItem('currentUser');
    if (currentUserJson) {
      const currentUser = JSON.parse(currentUserJson);
      this.trainerName = currentUser.user;
      this.trainerEmail = currentUser.email;
      console.log(currentUser)
      console.log(this.trainerName)
      this.getTrainer();
     this.getStats();
    } else {
      console.error('currentUser not found in local storage');
    }
  }

  getTrainer(): void {
    this.service.getProfile(this.trainerEmail)
      .subscribe(
        data => {
          console.log(data);
          this.trainer = data;
          this.splitName();
          this.formatDOB(); // Call formatDOB method after receiving data
        },
        error => {
          console.log(error);
          // Handle error
        }
      );
  }

  splitName(): void {
    if (this.trainer && this.trainer.name) {
      const parts = this.trainer.name.split(" ");
      if (parts.length >= 2) {
        this.fName = parts[0];
        this.lName = parts.slice(1).join(" ");
      } else {
        this.fName = parts[0];
        this.lName = "";
      }
    }
  }

  formatDOB(): void {
    if (this.trainer && this.trainer.dob) {
      // Format DOB using DatePipe
      this.dobFormatted = this.datePipe.transform(this.trainer.dob, 'dd/MM/yyyy');
    }
  }

  getStats(): void {
    this.service.getBatchStats(this.trainerName)
      .subscribe(data => {
        this.active = 0;
        this.comp = 0;
        this.assign =0;
        this.total = 0;

        data.forEach((batch: { status: string; }) => {
          if (batch.status === 'Active') {
            this.active++;
          } else if (batch.status === 'Completed') {
            this.comp++;
          } else if (batch.status === 'Created'){
            this.assign++;
          }
          this.total++;
        });
      });
  }
}

