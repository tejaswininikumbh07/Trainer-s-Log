import { Component, OnInit } from '@angular/core';
import { WriteBatch } from '../../../Model/write-batch';
import { BackEndService } from '../../../Services/back-end.service';
import { DatePipe } from '@angular/common';
import { NavDataService } from '../../../Services/nav-data-service.service';

@Component({
  selector: 'app-batch',
  templateUrl: './batch.component.html',
  styleUrl: './batch.component.scss'
})
export class BatchComponent implements OnInit{

  currentDate: Date = new Date(); // Current date
  currentHour: number = this.currentDate.getHours(); // Current hour
  currentTime: string = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
  ngOnInit(): void {
    setInterval(() => {
      this.currentDate = new Date();
      this.currentHour = this.currentDate.getHours();
      this.currentTime = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
    }, 1000);
  }
  batch: WriteBatch = new WriteBatch(); // Initialize an instance of WriteBatch
  

  constructor(private backendService: BackEndService, private datePipe: DatePipe, private navDataService: NavDataService) {
    this.navDataService.updateTrainerNavData(); }

  submitBatch() {
    const currentUserJson = sessionStorage.getItem('currentUser');
    const batchcode = this.batch.code;
    if (currentUserJson) {
      const currentUser = JSON.parse(currentUserJson);
      this.batch.trainer = currentUser.user;
      this.backendService.writeBatch(this.batch).subscribe(
        response => {
          alert(batchcode+ " Batch Saved Successfully!!")
          console.log('Batch submitted successfully!', response);
          // You can perform any additional actions here, such as resetting the form
          this.batch = new WriteBatch();
        },
        error => {
          // Handle error
          console.error('Error submitting batch:', error);
        }
      );
    } else {
      console.error('currentUser not found in local storage');
    }
    
  }
}
