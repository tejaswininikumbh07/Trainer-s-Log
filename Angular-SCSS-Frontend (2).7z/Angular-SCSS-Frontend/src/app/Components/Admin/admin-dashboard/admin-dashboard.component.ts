import { Component, OnInit } from '@angular/core';
import { NavDataService } from '../../../Services/nav-data-service.service';
import { DatePipe } from '@angular/common';
import { BackEndService } from '../../../Services/back-end.service';
import { Trainer } from '../../../Model/trainer';
import { Batch } from '../../../Model/batch';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.scss'
})
export class AdminDashboardComponent implements OnInit{

  javaTotalTrainers: number = 0;
  javaFemaleTrainers: number = 0;
  javaMaleTrainers: number = 0;
  javaMales: number = 0;
  javaFemales: number = 0;
  javaTotal: number = 0;
  javaActive: number = 0;
  javaAssigns: number = 0;
  javaComp: number =0;
  TotaljavaBatch: number = 0;

  cloudTotalTrainers: number = 0;
  cloudFemaleTrainers: number = 0;
  cloudMaleTrainerss: number = 0;
  cloudMales: number = 0;
  cloudFemales: number = 0;
  cloudTotal: number = 0;
  cloudActive: number = 0;
  cloudAssigns: number = 0;
  cloudComp: number =0;
  TotalcloudBatch: number = 0;
  mlTotalTrainers: number = 0;
  mlFemaleTrainers: number = 0;
  mlMaleTrainers: number = 0;
  mlMales: number = 0;
  mlFemales: number = 0;
  mlTotal: number = 0;
  mlActive: number = 0;
  mlAssigns: number = 0;
  mlComp: number =0;
  TotalmlBatch: number = 0;

  stTotalTrainers: number = 0;
  stFemaleTrainers: number = 0;
  stMaleTrainers: number = 0;
  stMales: number = 0;
  stFemales: number = 0;
  stTotal: number = 0;
  stActive: number = 0;
  stAssigns: number = 0;
  stComp: number =0;
  TotalstBatch: number = 0;

  aptiTotalTrainers: number = 0;
  aptiFemaleTrainers: number = 0;
  aptiMaleTrainers: number = 0;
  aptiMales: number = 0;
  aptiFemales: number = 0;
  aptiTotal: number = 0;
  aptiActive: number = 0;
  aptiAssigns: number = 0;
  aptiComp: number =0;
  TotalaptiBatch: number =0;

  ssTotalTrainers: number = 0;
  ssFemaleTrainers: number = 0;
  ssMaleTrainers: number = 0;
  ssMales: number = 0;
  ssFemales: number = 0;
  ssTotal: number = 0;
  ssActive: number = 0;
  ssAssigns: number = 0;
  ssComp: number =0;
  TotalssBatch: number = 0;

  TotalTrainers: number = 0;
  TotalFemaleTrainers: number = 0;
  TotalMaleTrainers: number = 0;
  TotalMales: number = 0;
  TotalFemales: number = 0;
  Total: number = 0;
  TotalActive: number = 0;
  TotalAssigns: number = 0;
  TotalComp: number =0;
  TotalBatch: number = 0;
  
  trainers: Trainer[] = [];
  batches: Batch[]=[];

  batchGrids: GridItem[][] = [
    [{ id: 1, value: "Java Full Stack" }, { id: 2, value: "Cloud Infrastructure Services" }, { id: 3, value: "Machine Learning" }, { id: 4, value: "Software Testing" }, { id: 6, value: "Softskills" }, { id: 7, value: "Total" }]
  ];

  initialValuesforBatch: GridItem[][] = [];

currentDate: Date = new Date(); // Current date
  currentHour: number = this.currentDate.getHours(); // Current hour
  currentTime: string = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';

  constructor(private datePipe: DatePipe, private backend: BackEndService, private navDataService: NavDataService) {
    this.navDataService.updateAdminNavData();
  }
  
  ngOnInit(): void { 
    localStorage.clear();
    this.fetchTrainers();
    this.fetchBatches();  
    this.navDataService.updateAdminNavData();
    
    this.initializeInitialValuesforBatch();
    this.initializeInitialValuesforTrainer();
    this.initializeInitialValuesforStudent();
    setInterval(() => {
      this.currentDate = new Date();
      this.currentHour = this.currentDate.getHours();
      this.currentTime = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
    }, 1000);
  }
  
  fetchTrainers(): void {
    this.backend.getAllTrainers().subscribe(
      (trainers: Trainer[]) => {
        this.trainers = trainers;
        localStorage.setItem('trainers', JSON.stringify(trainers));
        this.getTrainerCount();
    
      },
      (error) => {
        console.error('Error fetching trainers: ', error);
      }
    );
  }

  fetchBatches(): void{
    this.backend.getAllBatches().subscribe(
      (data: Batch[]) => {
        this.batches = data;
        localStorage.setItem('batches', JSON.stringify(this.batches)); // Store data in local storage
        this.getCount();
        this.getBatchStatus();
      },
      (error) => {
        console.error('Error fetching batches:', error);
      }
    );
  }

  private initializeInitialValuesforBatch() {
    this.initialValuesforBatch = this.batchGrids.map(row => row.map(grid => ({ id: grid.id, value: grid.value })));
  }
  private initializeInitialValuesforTrainer() {
    this.initialValuesforTrainer = this.trainerGrids.map(row => row.map(grid => ({ id: grid.id, value: grid.value })));
  }
  private initializeInitialValuesforStudent() {
    this.initialValuesforStudent = this.studentGrids.map(row => row.map(grid => ({ id: grid.id, value: grid.value })));
  }

  bmouseEnter(rowIndex: number, colIndex: number) {
    const grid = this.batchGrids[rowIndex][colIndex];
    if (grid) {
      // Change value based on ID 
      switch (grid.id) {
        case 1:
          grid.value = "Active Batches:    "+ this.javaActive+ "\nAssigned Batches:  "+ this.javaAssigns+"\nCompleted:  "+this.javaComp+ "\nTotal Batches: "+ this.TotaljavaBatch;
          break;
        case 2:
          grid.value = "Active Batches:    "+ this.cloudActive+ "\nAssigned Batches:  "+ this.cloudAssigns+"\nCompleted Batches:  "+ this.cloudComp+"\nTotal Batches: "+ this.TotalcloudBatch;
          break;
          case 3:
            grid.value = "Active Batches:    "+ this.mlActive+ "\nAssigned Batches:  "+ this.mlAssigns+"\nCompleted Batches:  "+ this.mlComp+"\nTotal Batches: "+ this.TotalmlBatch
            break;
            case 4:
              grid.value = "Active Batches:    "+ this.stActive+ "\nAssigned Batches:  "+ this.stAssigns+"\nCompleted Batches:  "+ this.stComp+"\nTotal Batches: "+this.TotalstBatch;
          break;
          // case 5:
          //   grid.value = "Active Batches:    "+ this.aptiActive+ "\nAssigned Batches:  "+ this.aptiAssigns+"\nCompleted Batches:  "+ this.aptiComp+"\nTotal Batches: "+ this.TotalaptiBatch
          // break;
          case 6:
            grid.value = "Active Batches:    "+ this.ssActive+ "\nAssigned Batches:  "+ this.ssAssigns+"\nCompleted Batches:  "+ this.ssComp+"\nTotal Batches: "+ this.TotalssBatch;
           break;
          case 7:
            grid.value = "Overall Active Batches:    "+ this.TotalActive+ "\nOverall Assigned Batches:  "+ this.TotalAssigns +"\nOverall Completed Batches:  "+ this.TotalComp+"\nTotal Batches: "+ this.TotalBatch;
           break;
      }
    }
  }

  bmouseLeave(rowIndex: number, colIndex: number) {
    const grid = this.batchGrids[rowIndex][colIndex];
    if (grid) {
      grid.value = this.initialValuesforBatch[rowIndex][colIndex].value;
    }
  }

  trainerGrids: GridItem[][] = [
    [{ id: 1, value: "Java Full Stack" }, { id: 2, value: "Cloud Infrastructure Services" }, { id: 3, value: "Machine Learning" }, { id: 4, value: "Software Testing" },  { id: 6, value: "Softskills" }, { id: 7, value: "Total" }]
  ];

  initialValuesforTrainer: GridItem[][] = [];

  tmouseEnter(rowIndex: number, colIndex: number) {
    const grid = this.trainerGrids[rowIndex][colIndex];
    if (grid) {
      // Change value based on ID 
      switch (grid.id) {
        case 1:
          grid.value = "Male Trainers:    "+ this.javaMaleTrainers+ "\nFemale Trainers:  "+ this.javaFemaleTrainers+"\nTotal:  "+ this.javaTotalTrainers;
          break;
        case 2:
          grid.value = "Male Trainers:    "+ this.cloudMaleTrainerss+ "\nFemale Trainers:  "+ this.cloudFemaleTrainers+"\nTotal:  "+ this.cloudTotalTrainers;
          break;
          case 3:
            grid.value = "Male Trainers:    "+ this.mlMaleTrainers+ "\nFemale Trainers:  "+ this.mlFemaleTrainers+"\nTotal:  "+ this.mlTotalTrainers;
            break;
            case 4:
          grid.value = "Male Trainers:    "+ this.stMaleTrainers+ "\nFemale Trainers:  "+ this.stFemaleTrainers+"\nTotal:  "+ this.stTotalTrainers;
          break;
          // case 5:
          //  grid.value = "Male Trainers:    "+ this.aptiMaleTrainers+ "\nFemale Trainers:  "+ this.aptiFemaleTrainers+"\nTotal:  "+ this.aptiTotalTrainers;
          //  break;
          case 6:
            grid.value = "Male Trainers:    "+ this.ssMaleTrainers+ "\nFemale Trainers:  "+ this.ssFemaleTrainers+"\nTotal:  "+ this.ssTotalTrainers;
           break;
          case 7:
           grid.value = "Male Trainers:    "+ this.TotalMaleTrainers+ "\nFemale Trainers:  "+ this.TotalFemaleTrainers+"\nTotal:  "+ this.TotalTrainers;
           break;
      }
    }
  }

  tmouseLeave(rowIndex: number, colIndex: number) {
    const grid = this.trainerGrids[rowIndex][colIndex];
    if (grid) {
      grid.value = this.initialValuesforTrainer[rowIndex][colIndex].value;
    }
  }

  studentGrids: GridItem[][] = [
    [{ id: 1, value: "Java Full Stack" }, { id: 2, value: "Cloud Infrastructure Services" }, { id: 3, value: "Machine Learning" }, { id: 4, value: "Software Testing" }, { id: 6, value: "Softskills" },{ id: 7, value: "Toatl Students in Academy" }]
  ];
  initialValuesforStudent: GridItem[][] = [];

  smouseEnter(rowIndex: number, colIndex: number) {
    const grid = this.studentGrids[rowIndex][colIndex];
    if (grid) {
      // Change value based on ID 
      switch (grid.id) {
        case 1:
          grid.value = "Male:    "+ this.javaMales+ "\nFemale:  "+ this.javaFemales+"\nTotal:  "+this.javaTotal;
          break;
        case 2:
          grid.value = "Male:    "+ this.cloudMales+ "\nFemale:  "+ this.cloudFemales+"\nTotal:  "+ this.cloudTotal;
          break;
          case 3:
            grid.value = "Male:    "+ this.mlMales+ "\nFemale:  "+ this.mlFemales+"\nTotal:  "+ this.mlTotal;
            break;
            case 4:
          grid.value = "Male:    "+ this.stMales+ "\nFemale:  "+ this.stFemales+"\nTotal:  "+ this.stTotal;
          break;
          case 5:
          grid.value = "Male:    "+ this.stMales+ "\nFemale:  "+ this.stFemales+"\nTotal:  "+ this.stTotal;
          break;
          case 6:
          grid.value = "Male:    "+ this.stMales+ "\nFemale:  "+ this.stFemales+"\nTotal:  "+ this.stTotal;
          break;
          case 7:
          grid.value = "Male:    "+ this.TotalMales+"\nFemale:  "+ this.TotalFemales+"\nTotal:  "+ this.Total;
          break;
      }
    }
  }

  smouseLeave(rowIndex: number, colIndex: number) {
    const grid = this.studentGrids[rowIndex][colIndex];
    if (grid) {
      grid.value = this.initialValuesforStudent[rowIndex][colIndex].value;
    }
  }



  getTrainerCount(): void {
    const TrainerString = localStorage.getItem('trainers');
    if (TrainerString) {
      const TrainerData: Trainer[] = JSON.parse(TrainerString);
      const TrainerCountMap: { [key: string]: { males: number, females: number, total: number } } = {};

      // Initialize variables to store total counts
      let totalMaleTrainers = 0;
      let totalFemaleTrainers = 0;
      let totalTrainers = 0;

      for (const trainer of TrainerData) {
        const category = trainer.batch;
        if (!TrainerCountMap[category]) {
          TrainerCountMap[category] = { males: 0, females: 0, total: 0 };
        }
        // Increment counts based on gender
        if (trainer.gender === 'Male') {
          TrainerCountMap[category].males++;
          totalMaleTrainers++;
        } else if (trainer.gender === 'Female') {
          TrainerCountMap[category].females++;
          totalFemaleTrainers++;
        }
        // Increment total count
        TrainerCountMap[category].total++;
        totalTrainers++;
      }

      // Assigning values to specific trainer counts
      for (const categoryName in TrainerCountMap) {
        const count = TrainerCountMap[categoryName];
        switch (categoryName) {
          case "Java Full Stack":
            this.javaMaleTrainers += count.males;
            this.javaFemaleTrainers += count.females;
            this.javaTotalTrainers += count.total;
            break;
          case "Cloud Infrastructure Services":
            this.cloudMaleTrainerss += count.males;
            this.cloudFemaleTrainers += count.females;
            this.cloudTotalTrainers += count.total;
            break;
          case "Machine Learning":
            this.mlMaleTrainers += count.males;
            this.mlFemaleTrainers += count.females;
            this.mlTotalTrainers = count.total;
            break;
          case "Software Testing":
            this.stMaleTrainers += count.males;
            this.stFemaleTrainers += count.females;
            this.stTotalTrainers += count.total;
            break;
          case "Aptitude":
            this.aptiMaleTrainers += count.males;
            this.aptiFemaleTrainers += count.females;
            this.aptiTotalTrainers += count.total;
            break;
          case "Softskills":
            this.ssMaleTrainers += count.males;
            this.ssFemaleTrainers += count.females;
            this.ssTotalTrainers += count.total;
            break;
        }
      }

      // Assign total counts
      this.TotalMaleTrainers = totalMaleTrainers;
      this.TotalFemaleTrainers = totalFemaleTrainers;
      this.TotalTrainers = totalTrainers;

    } else {
      console.error('No trainers found in local storage.');
    }
}









  getCount(): void {
    const batchesString = localStorage.getItem('batches');
    if (batchesString) {
      const batchesData: Batch[] = JSON.parse(batchesString);
      const batchCountMap: { [key: string]: { males: number, females: number, total: number } } = {};

      for (const batch of batchesData) { // Changed this.batches to batchesData
        if (!batchCountMap[batch.name]) {
          batchCountMap[batch.name] = { males: 0, females: 0, total: 0 };
        }
        batchCountMap[batch.name].males += batch.males;
        batchCountMap[batch.name].females += batch.females;
        batchCountMap[batch.name].total += batch.total;
      }

      // Assigning values to specific batch counts
      for (const batchName in batchCountMap) {
        const count = batchCountMap[batchName];
        switch (batchName) {
          case "Java Full Stack":
            this.javaMales = count.males;
            this.javaFemales = count.females;
            this.javaTotal = count.total;
            break;
          case "Cloud Infrastructure Services":
            this.cloudMales = count.males;
            this.cloudFemales = count.females;
            this.cloudTotal = count.total;
            break;
          case "Machine Learning":
            this.mlMales = count.males;
            this.mlFemales = count.females;
            this.mlTotal = count.total;
            break;
          case "Software Testing":
            this.stMales = count.males;
            this.stFemales = count.females;
            this.stTotal = count.total;
            break;
          case "Aptitude":
            this.aptiMales = count.males;
            this.aptiFemales = count.females;
            this.aptiTotal = count.total;
            break;
          case "Softskills":
            this.ssMales = count.males;
            this.ssFemales = count.females;
            this.ssTotal = count.total;
            break;
        }
        this.TotalMales=this.javaMales+this.cloudMales+this.mlMales+this.stMales;
        this.TotalFemales=this.javaFemales+this.cloudFemales+this.mlFemales+this.stFemales;
        this.Total=this.javaTotal+this.cloudTotal+this.mlTotal+this.stTotal;
        

      }

    } else {
      console.error('No batches found in local storage.');
    }
  }

  
  getBatchStatus(): void {
    const BatchStatusString = localStorage.getItem('batches');
    if (BatchStatusString) {
      const batchesData: Batch[] = JSON.parse(BatchStatusString);
  
      // Initialize counts for total batches, active batches, assigned batches, and completed batches
      let totalBatches = 0;
  
      for (const batch of batchesData) {
        const batchName = batch.name;
        const batchStatus = batch.status;
  
        // Increment total batches count
        totalBatches++;
  
        // Assign counts to specific batch variables
        switch (batchName) {
          case 'Java Full Stack':
            switch (batchStatus) {
              case 'Active':
                this.javaActive++;
                break;
              case 'Assigned':
                this.javaAssigns++;
                break;
              case 'Completed':
                this.javaComp++;
                break;
            }
            break;
            case "Cloud Infrastructure Services":
              switch (batchStatus) {
                case 'Active':
                  this.cloudActive++;
                  break;
                case 'Assigned':
                  this.cloudAssigns++
                  break;
                case 'Completed':
                  this.cloudComp++;
                  break;
              }
              break;
            case "Machine Learning":
              switch (batchStatus) {
                case 'Active':
                  this.mlActive++;
                  break;
                case 'Assigned':
                  this.mlAssigns++;
                  break;
                case 'Completed':
                  this.mlComp++;
                  break;
              }
              break;
            case "Software Testing":
              switch (batchStatus) {
                case 'Active':
                  this.stActive++;
                  break;
                case 'Assigned':
                  this.stAssigns++;
                  break;
                case 'Completed':
                  this.stComp++;
                  break;
              }
              break;
            case "Aptitude":
              switch (batchStatus) {
                case 'Active':
                  this.aptiActive++;
                  break;
                case 'Assigned':
                  this.aptiAssigns++;
                  break;
                case 'Completed':
                  this.aptiComp++;
                  break;
              }
              break;
            case "Softskills":
              switch (batchStatus) {
                case 'Active':
                  this.ssActive++;
                  break;
                case 'Assigned':
                  this.ssAssigns++;
                  break;
                case 'Completed':
                  this.ssComp++;
                  break;
              }
              break;
        }
        this.TotaljavaBatch = this.javaActive+this.javaComp+this.javaAssigns;
        this.TotalcloudBatch = this.cloudActive+this.cloudAssigns+this.cloudComp;
        this.TotalmlBatch = this.mlActive+this.mlAssigns+this.mlComp;
        this.TotalstBatch = this.stActive+this.stAssigns+this.stComp;
        this.TotalaptiBatch = this.aptiActive+this.aptiAssigns+this.aptiComp;
        this.TotalssBatch = this.ssActive+this.ssAssigns+this.ssComp;
        this.TotalActive= this.javaActive+this.cloudActive+this.mlActive+this.aptiActive+this.ssActive+this.stActive;
        this.TotalAssigns= this.javaAssigns+this.cloudAssigns+this.mlAssigns+this.aptiAssigns+this.ssAssigns+this.stAssigns;
        this.TotalComp = this.javaComp+this.cloudComp+this.mlComp+this.aptiComp+this.ssComp+this.stComp;
        this.TotalBatch= this.TotalActive+this.TotalAssigns+this.TotalComp;
      }
    } else {
      console.error('No batches found in local storage.');
    }
  }
  
 
}

interface GridItem {
  id: number;
  value: string | number; // Union type to accommodate both string and number
}