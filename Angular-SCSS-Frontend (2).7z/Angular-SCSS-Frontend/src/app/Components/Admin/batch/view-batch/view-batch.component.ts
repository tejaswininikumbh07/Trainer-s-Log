import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Batch } from '../../../../Model/batch';
import { BackEndService } from '../../../../Services/back-end.service';
import { BatchSchedule } from '../../../../Model/batch-schedule';
import { NavDataService } from '../../../../Services/nav-data-service.service';

@Component({
  selector: 'app-view-batch',
  templateUrl: './view-batch.component.html',
  styleUrl: './view-batch.component.scss'
})
export class ViewBatchComponent implements OnInit {
  sDate!: string;
  eDate!: string;
  batchLogs: BatchSchedule[] = [];
  batch: Batch = new Batch();
  id: number = 0;
  existingBatchCode: string[] = [];
  existingBatchName: string[] = [];
  list: string[][][] = [];
  trainers: string[] = [];
  trainerlist!: string[];
  batchlist!: string[];
  trainerName: any;
  BatchCode: any;
  BatchName: any;
  BatchID: any;
  currentDate: Date = new Date(); // Current date
  currentHour: number = this.currentDate.getHours(); // Current hour
  currentTime: string = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';


  constructor(private datePipe: DatePipe, private backendService: BackEndService, private navDataService: NavDataService) {
    this.navDataService.updateAdminNavData();
    this.backendService.getBatchLogs()
    .subscribe(res => {
      this.batch = res;
     // this.batchLogs = res;
      console.log("res: ", res)
      if (this.batch) {
        if (Array.isArray(this.batch)) {
          this.batch.forEach(batch => {
            if (batch && batch.code && batch.name) {
              this.existingBatchCode.push(batch.code)
              this.list.push([batch.id, batch.code, batch.name, batch.trainer]);
            }
          });
          console.log("list: ",this.list)
          this.batchLogs = this.batch;
          console.log("batchlogs1: "+this.batchLogs);
          this.batchLogs.sort((a, b) => {
            const dateA = new Date(a.date).getTime();
            const dateB = new Date(b.date).getTime();
            return dateB - dateA;
          });
          console.log("batchlogs2: "+this.batchLogs);
        }
        }
      }
    );
    console.log("batchlogs3: "+this.batchLogs);
   }

  ngOnInit(): void {
    setInterval(() => {
      this.currentDate = new Date();
      this.currentHour = this.currentDate.getHours();
      this.currentTime = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
    }, 1000);
    const today: Date = new Date();

    // Format the date to match the input[type="date"] format (YYYY-MM-DD)
    const formattedDate: string = this.formatDate(today);

    // Set the formatted date to the Date property
    this.eDate = formattedDate;
    // this.sDate = formattedDate;
  }
  formatDate(date: Date): string {
    const year: number = date.getFullYear();
    const month: number = date.getMonth() + 1;
    const day: number = date.getDate();

    // Ensure leading zeroes for month and day
    const monthString: string = (month < 10) ? '0' + month : '' + month;
    const dayString: string = (day < 10) ? '0' + day : '' + day;

    return `${year}-${monthString}-${dayString}`;
  }

  

  formatTime(timeString: string): string {
    // Assuming timeString is in HH:mm:ss format
    const [hours, minutes] = timeString.split(':');
    return `${hours}:${minutes}`;
  }
  formatDate2(date: Date): string {
    return this.datePipe.transform(date, 'dd-MM-yyyy') ?? '';
  }
  resetForm() {
    this.batchlist = [];
  }

  sortAndSaveBatchValue() {
    // Filter the list to include only batches with the provided BatchCode
    const filteredList = this.list.filter(batch => batch[1] === this.BatchCode);
    
    // Extract list[2] values and save them in a new array
    const listOfBatch: string[][] = filteredList.map(batch => batch[2]);
    this.batchlist = [];

    // Iterate through listOfBatch and concatenate batchlist
    for (let i = 0; i < listOfBatch.length; i++) {
        this.batchlist = this.batchlist.concat(listOfBatch[i]);
    }

    // Check the populated batchlist
    console.log('Batch list:', this.batchlist);
  }

  fetchBatchLogs() {
    this.backendService.getBatchLog(this.BatchCode, this.BatchName, this.sDate, this.eDate)
      .subscribe(
        (data: BatchSchedule[]) => {
          this.batchLogs = data;
          console.log('Batch logs:', this.batchLogs);
        },
        error => {
          console.log('Error fetching batch logs:', error);
        }
      );
  }
  getFile(): void {
    this.backendService.getBatchFile(this.BatchCode, this.BatchName, this.sDate, this.eDate)
      .subscribe(
        (data: Blob) => {
          // Create a blob URL for the response
          const blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          const url = window.URL.createObjectURL(blob);
          
          // Create a link element and click it to trigger download
          const a = document.createElement('a');
          a.href = url;
          a.download = 'BatchLog_'+this.BatchCode+'_'+this.BatchName+'.xlsx';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          
          // Clean up
          window.URL.revokeObjectURL(url);

          console.log('Download successful');
        },
        error => {
          console.error('Error downloading file:', error);
        }
      );
}
}
