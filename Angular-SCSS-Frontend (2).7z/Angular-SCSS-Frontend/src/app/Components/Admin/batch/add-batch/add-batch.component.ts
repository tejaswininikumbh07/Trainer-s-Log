import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BackEndService } from '../../../../Services/back-end.service';
import { Batch } from '../../../../Model/batch';
import Swal from 'sweetalert2';
import { DatePipe } from '@angular/common';
import { NavDataService } from '../../../../Services/nav-data-service.service';

@Component({
  selector: 'app-add-batch',
  templateUrl: './add-batch.component.html',
  styleUrl: './add-batch.component.scss'
})
export class AddBatchComponent implements OnInit{
  batch: Batch = new Batch();
  id:number =0;
  confirmpassword: any;
  roles!: string[];
  existingBatchCode: string[] = [];
  existingBatchName: string[] = [];
  trainers:string[]=[];
  trainerlist!:string[];
  trainerName: any;
  BatchCode: any;
  BatchName: any;
  batchExists: boolean = false;
  submitted: boolean = false;
  currentDate: Date = new Date(); // Current date
  currentHour: number = this.currentDate.getHours(); // Current hour
  currentTime: string = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';

  constructor(private backendService: BackEndService, private router: Router, private datePipe: DatePipe, private navDataService: NavDataService) {
    this.navDataService.updateAdminNavData();
    this.existingBatchCode = [];
    this.existingBatchName = [];
    const batchdetails = localStorage.getItem('batches');
    const trainerdetails = localStorage.getItem("trainers");
    if (batchdetails) {
      const batches = JSON.parse(batchdetails);
      if (Array.isArray(batches)) {
        batches.forEach(batch => {
          if (batch && batch.code && batch.name) {
            this.existingBatchCode.push(batch.code);
            this.existingBatchName.push(batch.name);
          }
        });
      }
    }

    if (trainerdetails) {
      const existTrainer = JSON.parse(trainerdetails);
      if (Array.isArray(existTrainer)) {
        existTrainer.forEach(trainer => {
          if (trainer && trainer.name) {
            this.trainers.push(trainer.name);
          }
        });
      }
    }
    this.trainerlist = this.trainers;
  }
  ngOnInit(): void {
    this.resetForm();
    setInterval(() => {
      this.currentDate = new Date();
      this.currentHour = this.currentDate.getHours();
      this.currentTime = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
    }, 1000);
  }

  CheckBatch() {
    // console.log(this.existingBatchCode);
    //  console.log(this.existingBatchName);
    if (this.existingBatchCode.includes(this.BatchCode) || this.existingBatchName.includes(this.BatchName)) {
      // console.log("code index: ",this.existingBatchCode.indexOf(this.BatchCode));
      // console.log("name index: ",this.existingBatchCode.indexOf(this.BatchName));
      this.batchExists = true;
    } else {
      // console.log("code index: ",this.existingBatchCode.indexOf(this.BatchCode));
      // console.log("name index: ",this.existingBatchCode.indexOf(this.BatchName));
      this.batchExists = false;
    }
  }



  SaveBatch() {
    this.submitted = true;
    this.CheckBatch();
    if (this.batchExists == true) {
      Swal.fire('Error', 'Batch with Batch code: '+ this.BatchCode +' and Batch Name: '+ this.BatchName+' already exists!', 'error');
    } else {
      this.batch.trainer = this.trainerName;
      this.batch.code = this.BatchCode;
      this.batch.name =this.BatchName;
      this.backendService.createBatch(this.batch)
        .subscribe(
          response => {
            Swal.fire({
              title: 'Success',
              html: 'Batch created successfully!<br>' + 
                    'Batch Code: ' + response.code + '<br>' + 
                    'Batch Name: ' + response.name + '<br>' + 
                    'Batch Strength: ' + response.total,
              icon: 'success',
              showCancelButton: true,
              confirmButtonText: 'Create Another Batch',
              cancelButtonText: 'Cancel'
            }).then((result) => {
              if (result.isConfirmed) {
                location.reload(); // Reload the component
              } else if (result.dismiss === Swal.DismissReason.cancel) {
                this.router.navigate(['/admin-dash']); // Navigate to admin dashboard if user dismisses the popup
              }
            });
                                           
          },
          error => {
            console.error(error);
            Swal.fire('Error', 'An error occurred while saving batch details!', 'error');
          }
        );
    }
  }

  resetForm() {
    this.submitted = false;
    this.batch = new Batch();
    this.BatchCode = null;
    this.BatchName = null;
  }
}