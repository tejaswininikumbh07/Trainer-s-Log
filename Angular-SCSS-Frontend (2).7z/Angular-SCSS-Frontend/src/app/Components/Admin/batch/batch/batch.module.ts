import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BatchRoutingModule } from './batch-routing.module';
import { BatchComponent } from './batch.component';
import { AddBatchComponent } from '../add-batch/add-batch.component';
import { DeleteBatchComponent } from '../delete-batch/delete-batch.component';
import { UpdateBatchComponent } from '../update-batch/update-batch.component';
import { ViewBatchComponent } from '../view-batch/view-batch.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    BatchComponent,
    AddBatchComponent,
    DeleteBatchComponent,
    UpdateBatchComponent,
    ViewBatchComponent
  ],
  imports: [
    CommonModule,
    BatchRoutingModule,
    FormsModule
  ]
})
export class BatchModule { }
