import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddBatchComponent } from '../add-batch/add-batch.component';
import { UpdateBatchComponent } from '../update-batch/update-batch.component';
import { DeleteBatchComponent } from '../delete-batch/delete-batch.component';
import { ViewBatchComponent } from '../view-batch/view-batch.component';

const routes: Routes = [
  {path: 'add', component: AddBatchComponent},
  {path: 'update', component: UpdateBatchComponent},
  {path: 'delete', component: DeleteBatchComponent},
  {path: 'view', component: ViewBatchComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BatchRoutingModule { }
