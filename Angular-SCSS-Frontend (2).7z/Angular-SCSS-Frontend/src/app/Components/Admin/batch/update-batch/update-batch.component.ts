import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { Batch } from '../../../../Model/batch';
import { BackEndService } from '../../../../Services/back-end.service';
import { DatePipe } from '@angular/common';
import { NavDataService } from '../../../../Services/nav-data-service.service';

@Component({
  selector: 'app-update-batch',
  templateUrl: './update-batch.component.html',
  styleUrls: ['./update-batch.component.scss'] // Use styleUrls instead of styleUrl
})
export class UpdateBatchComponent implements OnInit {
  batch: Batch = new Batch();
  id: number = 0;
  existingBatchCode: string[] = [];
  existingBatchName: string[] = [];
  list: string[][][] = [];
  trainers: string[] = [];
  trainerlist!: string[];
  batchlist!: string[];
  trainerName: any;
  BatchCode: any;
  BatchName: any;
  BatchID: any;
  currentDate: Date = new Date(); // Current date
  currentHour: number = this.currentDate.getHours(); // Current hour
  currentTime: string = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';


  constructor(private backendService: BackEndService, private router: Router,private datePipe: DatePipe, private navDataService: NavDataService) {
    this.navDataService.updateAdminNavData();
    this.existingBatchCode = [];
    this.existingBatchName = [];
    const batchdetails = localStorage.getItem('batches');
    const trainerdetails = localStorage.getItem("trainers");
    if (batchdetails) {
      const batches = JSON.parse(batchdetails);
      if (Array.isArray(batches)) {
        batches.forEach(batch => {
          if (batch && batch.code && batch.name) {
            this.existingBatchCode.push(batch.code);
            this.existingBatchName.push(batch.name);
            this.list.push([batch.id, batch.code, batch.name]);
          }
        });
      }
    }

    if (trainerdetails) {
      const existTrainer = JSON.parse(trainerdetails);
      if (Array.isArray(existTrainer)) {
        existTrainer.forEach(trainer => {
          if (trainer && trainer.name) {
            this.trainers.push(trainer.name);
          }
        });
      }
    }
    this.trainerlist = this.trainers;
  }

  ngOnInit(): void {
    this.resetForm();
    setInterval(() => {
      this.currentDate = new Date();
      this.currentHour = this.currentDate.getHours();
      this.currentTime = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
    }, 1000);
  }

  getBatchID() {
    const foundBatch = this.list.find(batch => batch[1] === this.BatchCode && batch[2] === this.BatchName);
    if (foundBatch) {
      this.BatchID = foundBatch[0];
    } else {
      alert("Batch Not Found");
    }
  }

  UpdateBatch(): void {
    this.batch.id = this.BatchID;
    this.batch.name = this.BatchName;
    this.batch.code = this.BatchCode;
    this.batch.trainer = this.trainerName;
    console.log(this.batch);
    this.backendService.updateBatch(this.batch)
      .subscribe(
        () => {
          console.log('Batch updated successfully');
          Swal.fire({
            title: 'Success',
            text: 'Batch updated successfully',
            icon: 'success'
          });
          this.resetForm();
        },
        (error) => {
          console.error('Error updating batch:', error);
          // Handle error, such as showing an error message
        }
      );
  }

  resetForm() {
    this.batch = new Batch();
    this.BatchCode = null;
    this.BatchName = null;
  }

  toggleInputs() {
    // logic to enable/disable inputs based on the selected choice
    const choice = this.batch.choice;
    if (choice === 'name') {
      this.disableAllInputsExcept('batch-name');
    } else if (choice === 'trainer') {
      this.disableAllInputsExcept('trainer-name');
    } else if (choice === 'males') {
      this.disableAllInputsExcept('male-students');
    } else if (choice === 'females') {
      this.disableAllInputsExcept('female-students');
    } else if (choice === 'startdate') {
      this.disableAllInputsExcept('start-date');
    } else if (choice === 'enddate') {
      this.disableAllInputsExcept('end-date');
    } else if (choice === 'status') {
      this.disableAllInputsExcept('status');
    }
  }

  disableAllInputsExcept(exceptId: string) {
    const inputs = ['batch-name', 'trainer-name', 'male-students', 'female-students', 'start-date', 'end-date', 'status'];
    inputs.forEach(id => {
      const inputElement = document.getElementById(id) as HTMLInputElement;
      if (id === exceptId) {
        inputElement.disabled = false;
      } else {
        inputElement.disabled = true;
      }
    });
  }

  sortAndSaveBatchValue() {
    // Filter the list to include only batches with the provided BatchCode
    const filteredList = this.list.filter(batch => batch[1] === this.BatchCode);
    
    // Extract list[2] values and save them in a new array
    const listOfBatch: string[][] = filteredList.map(batch => batch[2]);
    this.batchlist = [];

    // Iterate through listOfBatch and concatenate batchlist
    for (let i = 0; i < listOfBatch.length; i++) {
        this.batchlist = this.batchlist.concat(listOfBatch[i]);
    }

    // Check the populated batchlist
    console.log('Batch list:', this.batchlist);
  }
}