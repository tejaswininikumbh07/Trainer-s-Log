import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { Batch } from '../../../../Model/batch';
import { BackEndService } from '../../../../Services/back-end.service';
import { NavDataService } from '../../../../Services/nav-data-service.service';

@Component({
  selector: 'app-delete-batch',
  templateUrl: './delete-batch.component.html',
  styleUrl: './delete-batch.component.scss'
})
export class DeleteBatchComponent implements OnInit {
  sDate!: string;
  eDate!: string;
  batchLogs: Batch[] = [];
  batch: Batch = new Batch();
  id: number = 0;
  existingBatchCode: string[] = [];
  existingBatchName: string[] = [];
  list: any[][] = [];
  trainers: string[] = [];
  trainerlist!: string[];
  batchlist!: string[];
  trainerName: any;
  BatchCode: any;
  BatchName: any;
  BatchID: any;
  currentDate: Date = new Date(); // Current date
  currentHour: number = this.currentDate.getHours(); // Current hour
  currentTime: string = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
  selectedRow: any; // Variable to store the selected row


  constructor(private datePipe: DatePipe, private backendService: BackEndService, private navDataService: NavDataService) {
    this.navDataService.updateAdminNavData();
    this.laodTabel();
  }
  laodTabel(){
    this.backendService.getAllBatches().subscribe((res: Batch[]) => {
      this.batchLogs = res;
     // console.log("res: ", res);
      if (this.batchLogs && this.batchLogs.length > 0) {
        this.batchLogs.forEach(batch => {
          if (batch && batch.code && batch.name) {
            this.existingBatchCode.push(batch.code);
            this.list.push([batch.id, batch.code, batch.name]);
          }
        });
        //console.log("list: ", this.list);
        this.batchLogs.sort((a, b) => {
          // sort by id
          return a.id - b.id;
        });
      }
    });
  }

  // Function to handle row selection
  selectRow(row: any) {
    this.selectedRow = row;
    console.log('Selected Row:', row);
    this.BatchID = row.id;
    console.log(this.BatchID);
    // You can perform any action with the selected row here
  }
  ngOnInit(): void {
    this.laodTabel();
    setInterval(() => {
      this.currentDate = new Date();
      this.currentHour = this.currentDate.getHours();
      this.currentTime = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
    }, 1000);
    const today: Date = new Date();
    this.resetForm();
    // this.fetchBatchLogs();

    // Format the date to match the input[type="date"] format (YYYY-MM-DD)
    const formattedDate: string = this.formatDate(today);

    // Set the formatted date to the Date property
    this.eDate = formattedDate;
    // this.sDate = formattedDate;
  }
  formatDate(date: Date): string {
    const year: number = date.getFullYear();
    const month: number = date.getMonth() + 1;
    const day: number = date.getDate();

    // Ensure leading zeroes for month and day
    const monthString: string = (month < 10) ? '0' + month : '' + month;
    const dayString: string = (day < 10) ? '0' + day : '' + day;

    return `${year}-${monthString}-${dayString}`;
  }

  

  resetForm() {
    this.batchlist = [];
  }

  fetchBatchLogs() {
    this.backendService.searchBatchByCode(this.BatchCode).subscribe(
      (data: Batch | Batch[]) => { // Accepts either a single Batch object or an array of Batch objects
        if (Array.isArray(data)) {
          console.log(data);
          this.batchLogs = data; // Assign the array of Batch objects
         // console.log('Batch logs:', this.batchLogs);
        } else {
          console.log(data);
          this.batchLogs = [data]; // Convert the single Batch object into an array
         // console.log('Batch logs:', this.batchLogs);
        }
      },
      error => {
        console.log('Error fetching batch logs:');
      }
    );
  }

  deleteBatch() {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You are about to delete this batch!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        // User confirmed deletion, call backend service to delete batch
        this.backendService.deleteBatch(this.BatchID).subscribe(
          response => {
            // Handle successful deletion response if needed
            Swal.fire('Deleted!', 'Batch has been deleted.', 'success');
            this.ngOnInit();
          },
          error => {
            console.log('Error deleting batch:', error);
            Swal.fire('Error!', 'Failed to delete batch. Please try again later.', 'error');
          }
        );
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        // User clicked cancel, do nothing
        Swal.fire('Cancelled', 'Batch deletion was cancelled.', 'info');
      }
    });
  }
  
  
  
}
