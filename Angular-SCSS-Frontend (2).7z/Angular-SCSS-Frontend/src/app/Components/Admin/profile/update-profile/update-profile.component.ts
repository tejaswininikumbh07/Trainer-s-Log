import { Component, OnInit } from '@angular/core';
import { BackEndService } from '../../../../Services/back-end.service';
import { Admin } from '../../../../Model/admin';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { NavDataService } from '../../../../Services/nav-data-service.service';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrl: './update-profile.component.scss'
})
export class UpdateProfileComponent implements OnInit {
  
  admin: Admin = new Admin();
  id:number =0;
  confirmpassword: any;
  choice: any;
  activeField: string | null = null; 
  currentDate: Date = new Date(); // Current date
  currentHour: number = this.currentDate.getHours(); // Current hour
  currentTime: string = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
  passwordField: FormControl | undefined;


  constructor(private adminService: BackEndService, private router: Router,private datePipe: DatePipe, private navDataService: NavDataService) {
    this.navDataService.updateAdminNavData();
    console.log(this.choice);
    this.passwordField = new FormControl('', Validators.required);
   }

  ngOnInit(): void {
    // Fetch admin details from backend on component initialization
    this.fetchAdminID();
    setInterval(() => {
      this.currentDate = new Date();
      this.currentHour = this.currentDate.getHours();
      this.currentTime = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
    }, 1000);
  }
  setActive(field: string) {
    if (this.activeField === field) {
      this.activeField = null; // Toggle off if already active
    } else {
      this.activeField = field; // Activate the clicked field
    }
  }
  

  isActive(field: string): boolean {
    return this.activeField === field;
  }
  

  fetchAdminID(): void {
    const details = localStorage.getItem('Admin');
    if (details) {
      const currentUser = JSON.parse(details);
      this.admin.id = currentUser.id || '';
      this.admin = currentUser;
    }
  }
  updateAdmin(): void {
    this.adminService.updateAdmin(this.admin).subscribe(updatedAdmin => {
      // Handle success response
      console.log("See: ",updatedAdmin);
      alert('Details updated successfully\n Note Your Login Details: Username: ' + updatedAdmin.email + ', Password: ' + updatedAdmin.pass);
      localStorage.setItem('Admin', JSON.stringify(updatedAdmin));
      this.router.navigate(['/profile/view']);
    }, error => {
      // Handle error
      console.error('Error updating admin:', error);
      
      // You may want to show an error message to the user
    });
  }
  containsNumber(value: string): boolean {
    return /\d/.test(value);
}
containsSpecialSymbol(password: string): boolean {
  const specialSymbols = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
  return specialSymbols.test(password);
}
containsUppercaseLetter(password: string): boolean {
  const uppercaseRegex = /[A-Z]/;
  return uppercaseRegex.test(password);
}

  
}
