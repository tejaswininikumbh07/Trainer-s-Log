import { Component, OnInit } from '@angular/core';
import { Admin } from '../../../../Model/admin';
import { BackEndService } from '../../../../Services/back-end.service';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { NavDataService } from '../../../../Services/nav-data-service.service';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrl: './view-profile.component.scss'
})
export class ViewProfileComponent implements OnInit {

  admin: Admin = new Admin;
  email: string= '';
  Ce:string='';
  
  academyEmail = "sda@sspu.ac.in";
  fName: string | undefined;
  lName: string | undefined;
  dobFormatted: any | undefined; // Add a property to store formatted DOB

  constructor(private service: BackEndService, private datePipe :DatePipe, private router: Router, private navDataService: NavDataService) {
    this.navDataService.updateAdminNavData(); }

  ngOnInit(): void {
    const currentUserString = sessionStorage.getItem('currentUser');
    const AdminDetails= localStorage.getItem('Admin');
    if (AdminDetails){
      const adminUser= JSON.parse(AdminDetails)
      this.email = adminUser.email;
    }else if (currentUserString) {
      const currentUser = JSON.parse(currentUserString);
      this.email = currentUser.email || '';
    }
    this.getAdmin(this.email);
    this.splitName();
    this.formatDOB();
  }

  getAdmin(email: string): void {
    this.service.getAdmin(email)
      .subscribe((admin: Admin) => {
          this.admin = admin;
          localStorage.setItem('Admin', JSON.stringify(admin));
          this.splitName();
          this.formatDOB();
      }, 
      (error) => {
          console.error('An error occurred:', error);
          // Handle the error here
      });
}
  splitName(): void {
    if (this.admin && this.admin.name) {
      const parts = this.admin.name.split(" ");
      if (parts.length >= 2) {
        this.fName = parts[0];
        this.lName = parts.slice(1).join(" ");
      } else {
        this.fName = parts[0];
        this.lName = "";
      }
    }
  }

  formatDOB(): void {
    if (this.admin && this.admin.dob) {
      // Format DOB using DatePipe
      this.dobFormatted = this.datePipe.transform(this.admin.dob, 'dd/MM/yyyy');
    }
  }
  EditProfile() {
    this.router.navigate(['/profile/customize']);
    }

}
