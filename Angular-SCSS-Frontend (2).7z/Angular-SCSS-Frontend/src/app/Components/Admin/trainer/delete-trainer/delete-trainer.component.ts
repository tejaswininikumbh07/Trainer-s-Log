import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { Batch } from '../../../../Model/batch';
import { BackEndService } from '../../../../Services/back-end.service';
import { Trainer } from '../../../../Model/trainer';
import { Router } from '@angular/router';
import { NavDataService } from '../../../../Services/nav-data-service.service';

@Component({
  selector: 'app-delete-trainer',
  templateUrl: './delete-trainer.component.html',
  styleUrl: './delete-trainer.component.scss'
})
export class DeleteTrainerComponent implements OnInit {
  TrainerDetails: Trainer[] = [];
  list: Trainer[][] = [];
  trainerName: any;
  TrainerID: any;
  currentDate: Date = new Date(); // Current date
  currentHour: number = this.currentDate.getHours(); // Current hour
  currentTime: string = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
  selectedRow: any;


  constructor(private datePipe: DatePipe, private backendService: BackEndService, router: Router, private navDataService: NavDataService) {
    this.navDataService.updateAdminNavData();
    this.laodTabel();
  }
  laodTabel() {
    const trainerdetails = localStorage.getItem("trainers");
    if (trainerdetails) {
      const existTrainer = JSON.parse(trainerdetails);
      if (Array.isArray(existTrainer)) {
        existTrainer.forEach(trainer => {
          if (trainer) {
            this.list.push(trainer); // Push the trainer into the list
          }
        });
      }
    }
    // Flatten the list and assign it to TrainerDetails
    this.TrainerDetails = this.list.reduce((acc, val) => acc.concat(val), []);
    console.log(this.TrainerDetails);
  }

  // Function to handle row selection
  selectRow(row: any) {
    this.selectedRow = row;
    console.log('Selected Row:', row);
    this.TrainerID = row.id;
    console.log(this.TrainerID);
    // You can perform any action with the selected row here
  }
  ngOnInit(): void {
   // this.laodTabel();
    setInterval(() => {
      this.currentDate = new Date();
      this.currentHour = this.currentDate.getHours();
      this.currentTime = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
    }, 1000);
    const today: Date = new Date();
  }
  
  fetchTrainer() {
    // Clear existing TrainerDetails
    this.TrainerDetails = [];
  
    // Find the trainer by name in the list
    for (const trainer of this.list.flat()) {
      // Check if the current trainer's name matches the specified trainerName
      if (trainer.name === this.trainerName) {
        // If found, assign the trainer to TrainerDetails
        this.TrainerDetails.push(trainer);
      }
    }
  
    // Check if any trainers are found
    if (this.TrainerDetails.length > 0) {
      console.log('Trainers found:', this.TrainerDetails);
    } else {
      console.log('No trainer found with the name:', this.trainerName);
    }
    this.ngOnInit();
  }
  
  
  
  
  
  

  deleteBatch() {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You are about to delete this Trainer!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        // User confirmed deletion, call backend service to delete batch
        this.backendService.deleteTrainer(this.TrainerID).subscribe(
          response => {
            // Handle successful deletion response if needed
            Swal.fire('Deleted!', 'Trainer has been deleted.', 'success');
            this.laodTabel();
            this.ngOnInit();
          },
          error => {
            console.log('Error deleting Trainer:', error);
            Swal.fire('Error!', 'Failed to delete Trainer. Please try again later.', 'error');
          }
        );
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        // User clicked cancel, do nothing
        Swal.fire('Cancelled', 'Trainer deletion was cancelled.', 'info');
      }
    });
  }
  
  
  
}
