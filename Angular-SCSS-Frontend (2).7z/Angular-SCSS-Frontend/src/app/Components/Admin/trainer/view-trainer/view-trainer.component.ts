import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { BackEndService } from '../../../../Services/back-end.service';
import { TrainerLog } from '../../../../Model/trainer-log';
import { NavDataService } from '../../../../Services/nav-data-service.service';

@Component({
  selector: 'app-view-trainer',
  templateUrl: './view-trainer.component.html',
  styleUrl: './view-trainer.component.scss'
})
export class ViewTrainerComponent implements OnInit {
  sDate!: string;
  eDate!: string;
  trainerName: any;
  
  //  sDate= "2024-03-06";
  //  eDate="2024-04-01";
  //  trainerName ="Krishna Keshav";

  trainerLogs: TrainerLog[] = [];
  trainer: TrainerLog = new TrainerLog();
  id: number = 0;
  list: string[][][] = [];
  trainers: string[] = [];
  trainerlist!: string[];
  currentDate: Date = new Date(); // Current date
  currentHour: number = this.currentDate.getHours(); // Current hour
  currentTime: string = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';


  constructor(private datePipe: DatePipe, private backendService: BackEndService, private navDataService: NavDataService) {
    this.navDataService.updateAdminNavData();
    this.backendService.getTrainerLogs()
    .subscribe(res => {
      this.trainer = res;
      console.log("res: ", res)
      if (this.trainer) {
        if (Array.isArray(this.trainer)) {
          this.trainer.forEach(trainerdetails => {
            if (trainerdetails) {
              //this.existingBatchCode.push(batch.code)
              this.list.push([trainerdetails.id, trainerdetails.loginDate, trainerdetails.loginTime, trainerdetails.logoutTime, trainerdetails.trainerName]);
            }
          });
          console.log("list: ",this.list)
          this.trainerLogs = this.trainer;
          this.trainerLogs.sort((a, b) => {
            const dateA: Date = new Date(a.loginDate);
            const dateB: Date = new Date(b.loginDate);
            return dateB.getTime() - dateA.getTime();
          });
          console.log(this.trainerLogs);
        }
        }
      }
    );
    const trainerdetails = localStorage.getItem("trainers");
 if (trainerdetails) {
      const existTrainer = JSON.parse(trainerdetails);
      if (Array.isArray(existTrainer)) {
        existTrainer.forEach(trainer => {
          if (trainer && trainer.name) {
            this.trainers.push(trainer.name);
          }
        });
      }
    }
    this.trainerlist = this.trainers;
    this.Laod();
   }

  ngOnInit(): void {
    setInterval(() => {
      this.currentDate = new Date();
      this.currentHour = this.currentDate.getHours();
      this.currentTime = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
    }, 1000);
    const today: Date = new Date();

    // Format the date to match the input[type="date"] format (YYYY-MM-DD)
    const formattedDate: string = this.formatDate(today);

    // Set the formatted date to the Date property
    this.eDate = formattedDate;
    // this.sDate = formattedDate;
  }
  formatDate(date: Date): string {
    const year: number = date.getFullYear();
    const month: number = date.getMonth() + 1;
    const day: number = date.getDate();

    // Ensure leading zeroes for month and day
    const monthString: string = (month < 10) ? '0' + month : '' + month;
    const dayString: string = (day < 10) ? '0' + day : '' + day;

    return `${year}-${monthString}-${dayString}`;
  }

  

  formatTime(timeString: string): string {
    // Assuming timeString is in HH:mm:ss format
    const [hours, minutes] = timeString.split(':');
    return `${hours}:${minutes}`;
  }
  formatDate2(date: Date): string {
    return this.datePipe.transform(date, 'dd-MM-yyyy') ?? '';
  }
 

  // sortAndSaveBatchValue() {
  //   // Filter the list to include only batches with the provided BatchCode
  //   const filteredList = this.list.filter(batch => batch[1] === this.trainerlist);
  
  //   // Extract list[2] values and save them in a new array
  //   const listOfBatch: string[][] = filteredList.map(batch => batch[2]);
  //   this.trainerlist = [];
  //
  
  //   // Iterate through listOfBatch and concatenate batchlist
  //   for (let i = 0; i < listOfBatch.length; i++) {
  //       this.trainerlist = this.trainerlist.concat(listOfBatch[i]);
  //   }

  //   // Check the populated batchlist
  //   console.log('Batch list:', this.trainerlist);
  // }

  fetchLogs() {
    this.backendService.getLog(this.trainerName, this.sDate, this.eDate)
      .subscribe(
        (data: TrainerLog | TrainerLog[]) => { // Accepts either a single Batch object or an array of Batch objects
          if (Array.isArray(data)) {
            console.log(data);
            this.trainerLogs = data; // Assign the array of Batch objects
           // console.log('Batch logs:', this.batchLogs);
          } else {
            console.log(data);
            this.trainerLogs = [data]; // Convert the single Batch object into an array
           // console.log('Batch logs:', this.batchLogs);
          }
          console.log('logs:', this.trainerLogs);
        },
        error => {
          console.log('Error fetching batch logs:', error);
        }
      );
  }
  Laod(){
    this.backendService.getTrainerLogs()
      .subscribe(
        (data: TrainerLog | TrainerLog[]) => { // Accepts either a single Batch object or an array of Batch objects
          if (Array.isArray(data)) {
            console.log(data);
            this.trainerLogs = data; // Assign the array of Batch objects
           // console.log('Batch logs:', this.batchLogs);
          } else {
            console.log(data);
            this.trainerLogs = [data]; // Convert the single Batch object into an array
           // console.log('Batch logs:', this.batchLogs);
          }
          console.log('logs:', this.trainerLogs);
        },
        error => {
          console.log('Error fetching batch logs:', error);
        }
      );

  }
  getFile(): void {
    this.backendService.getTrainerFile(this.trainerName, this.sDate, this.eDate)
      .subscribe(
        (data: Blob) => {
          // Create a blob URL for the response
          const blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          const url = window.URL.createObjectURL(blob);
          
          // Create a link element and click it to trigger download
          const a = document.createElement('a');
          a.href = url;
          a.download = 'TrainerLog_'+this.trainerName+'_'+this.sDate+'to'+this.eDate+'.xlsx';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          
          // Clean up
          window.URL.revokeObjectURL(url);

          console.log('Download successful');
        },
        error => {
          console.error('Error downloading file:', error);
        }
      );
}
}
