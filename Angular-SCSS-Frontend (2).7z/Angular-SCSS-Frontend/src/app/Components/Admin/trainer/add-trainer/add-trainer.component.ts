import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { Batch } from '../../../../Model/batch';
import { BackEndService } from '../../../../Services/back-end.service';
import { Trainer } from '../../../../Model/trainer';
import { NavDataService } from '../../../../Services/nav-data-service.service';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-trainer',
  templateUrl: './add-trainer.component.html',
  styleUrls: ['./add-trainer.component.scss']
})
export class AddTrainerComponent implements OnInit {
 trainer: Trainer = new Trainer();
  existingBatchCode: string[] = [];
  existingBatchName: string[] = [];
  trainerlist: string[] = [];
  list:String[][]=[];
  trainerName: any;
  trainerExists: boolean = false;
  currentDate: Date = new Date(); // Current date
  currentHour: number = this.currentDate.getHours(); // Current hour
  currentTime: string = this.datePipe.transform(this.currentDate, 'shortTime') || '';
  trainerEmail: any;
  trainerBatch: any;
  password: string = '';
  confirmPassword: string = '';
  passwordField: FormControl | undefined;

  constructor(
    private backendService: BackEndService,
    private router: Router,
    private datePipe: DatePipe,
     private navDataService: NavDataService) {
      this.navDataService.updateAdminNavData();
      this.passwordField = new FormControl('', Validators.required);
    }

  ngOnInit(): void {
    this.resetForm();
    setInterval(() => {
      this.currentDate = new Date();
      this.currentHour = this.currentDate.getHours();
      this.currentTime = this.datePipe.transform(this.currentDate, 'shortTime') || '';
    }, 1000);
    this.existingBatchCode = [];
    this.existingBatchName = [];
    const batchdetails = localStorage.getItem('batches');
    const trainerdetails = localStorage.getItem("trainers");
    if (batchdetails) {
      const batches = JSON.parse(batchdetails);
      if (Array.isArray(batches)) {
        batches.forEach(batch => {
          if (batch && batch.code && batch.name) {
            this.existingBatchCode.push(batch.code);
            this.existingBatchName.push(batch.name);
           // this.list.push([batch.id, batch.code, batch.name]);
          }
        });
      }
    }

    if (trainerdetails) {
      const existTrainer = JSON.parse(trainerdetails);
      if (Array.isArray(existTrainer)) {
        existTrainer.forEach(trainer => {
          if (trainer && trainer.name) {
            this.trainerlist.push(trainer.name);
            this.list.push([trainer.name, trainer.email , trainer.batch])
          }
        });
      }
    }

  }

  // CheckBatch() {
  //   if (this.existingBatchCode.includes(this.BatchCode) || this.existingBatchName.includes(this.BatchName)) {
  //     this.batchExists = true;
  //   } else {
  //     this.batchExists = false;
  //   }
  // }
  CheckExistance() {
    const isTrainerExisting = this.list.some(item => item[0] === this.trainerName && item[1] === this.trainerEmail && item[2] === this.trainerBatch);
  
    if (isTrainerExisting) {
      this.trainerExists = true;
      console.log("Trainer exists");
    } else {
      this.trainerExists = false;
      console.log("Trainer does not exist");
    }
  }
  
  

  Save() {
    this.CheckExistance();
    if (this.trainerExists) {
      Swal.fire('Error', ' already exists!', 'error');
    } else {
      this.trainer.name = this.trainerName;
      this.trainer.email = this.trainerEmail;
      this.trainer.batch = this.trainerBatch;
      this.backendService.createTrainer(this.trainer)
        .subscribe(
          response => {
            Swal.fire({
              title: 'Success',
              html: `Trainer Added successfully!<br> Trainer Name: ${response.name} <br>-: Login Details :- <br>Username: ${response.email} <br> Password: ${response.pass}`,
              icon: 'success',
              showCancelButton: true,
              confirmButtonText: 'Add Another Trainer',
              cancelButtonText: 'Cancel'
            }).then((result) => {
              if (result.isConfirmed) {
                location.reload(); // Reload the component
              } else if (result.dismiss === Swal.DismissReason.cancel) {
                this.router.navigate(['/admin-dash']); // Navigate to admin dashboard if user dismisses the popup
              }
            });                  
          },
          error => {
            console.error(error);
            Swal.fire('Error', 'An error occurred while saving Trainer details!', 'error');
          }
        );
    }
  }

  resetForm() {
    this.trainer = new Trainer();
    this.trainerName = null;
    this.trainerEmail = null;
    this.trainerBatch = null;
  }

  containsNumber(value: string): boolean {
    return /\d/.test(value);
}
containsSpecialSymbol(password: string): boolean {
  const specialSymbols = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
  return specialSymbols.test(password);
}
containsUppercaseLetter(password: string): boolean {
  const uppercaseRegex = /[A-Z]/;
  return uppercaseRegex.test(password);
}

}
