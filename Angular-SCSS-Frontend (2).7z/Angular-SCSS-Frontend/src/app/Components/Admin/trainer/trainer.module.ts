import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { TrainerRoutingModule } from './trainer-routing.module';
import { TrainerComponent } from './trainer/trainer.component';
import { AddTrainerComponent } from './add-trainer/add-trainer.component';
import { UpdateTrainerComponent } from './update-trainer/update-trainer.component';
import { DeleteTrainerComponent } from './delete-trainer/delete-trainer.component';
import { ViewTrainerComponent } from './view-trainer/view-trainer.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    TrainerComponent,
    AddTrainerComponent,
    UpdateTrainerComponent,
    DeleteTrainerComponent,
    ViewTrainerComponent
  ],
  imports: [
    CommonModule,
    TrainerRoutingModule,
    FormsModule
  ],
  providers: [DatePipe]
})
export class TrainerModule { }
