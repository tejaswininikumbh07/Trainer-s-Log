import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { BackEndService } from '../../../../Services/back-end.service';
import { Trainer } from '../../../../Model/trainer';
import { NavDataService } from '../../../../Services/nav-data-service.service';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-update-trainer',
  templateUrl: './update-trainer.component.html',
  styleUrl: './update-trainer.component.scss'
})
export class UpdateTrainerComponent implements OnInit {
call() {
throw new Error('Method not implemented.');
}
  trainer: Trainer = new Trainer();
  id!: number ;
  existingBatchCode: string[] = [];
  existingBatchName: string[] = [];
  list: string[][] = [];
  trainers: string[] = [];
  trainerlist!: string[];
  batchlist!: string[];
  trainerName: any;
  BatchCode: any;
  BatchName: any;
  TrainerID: any;
  currentDate: Date = new Date(); // Current date
  currentHour: number = this.currentDate.getHours(); // Current hour
  currentTime: string = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
confirmpassword: any;
isSubmitted = false;
passwordField: FormControl | undefined;

  constructor(private backendService: BackEndService, private router: Router,private datePipe: DatePipe, private navDataService: NavDataService) {
    this.navDataService.updateAdminNavData();
    this.existingBatchCode = [];
    this.existingBatchName = [];
    this.passwordField = new FormControl('', Validators.required);
   // const batchdetails = localStorage.getItem('batches');
    const trainerdetails = localStorage.getItem("trainers");
    // if (trainerdetails) {
    //   const batches = JSON.parse(trainerdetails);
    //   if (Array.isArray(batches)) {
    //     batches.forEach(trainer => {
    //       if (trainer && trainer.code && trainer.name) {
    //         this.existingBatchCode.push(trainer.code);
            
    //       }
    //     });
    //   }
     
    // }

    if (trainerdetails) {
      const existTrainer = JSON.parse(trainerdetails);
      if (Array.isArray(existTrainer)) {
        existTrainer.forEach(trainer => {
          if (trainer && trainer.name) {
            this.trainers.push(trainer.name);
            this.list.push([trainer.id, trainer.name]);
          }
        });
      }
    }
    this.trainerlist = this.trainers;
    console.log(this.list);
  }

  ngOnInit() {
    this.resetForm();
    setInterval(() => {
      this.currentDate = new Date();
      this.currentHour = this.currentDate.getHours();
      this.currentTime = this.datePipe.transform(this.currentDate, 'shortTime') ?? '';
    }, 1000);
  }

  getTrainerID() {
    const foundTrainer = this.list.find(trainer => trainer[1] === this.trainerName);

    if (foundTrainer) {
      this.TrainerID = foundTrainer[0];
      console.log(this.TrainerID);
    } else {
      alert("Trainer Not Found");
    }
  }


  

 
  UpdateTrainer(): void {
    this.isSubmitted = true;
    this.trainer.id = this.TrainerID;
    console.log(this.trainer);
    this.backendService.updateTrainerDetails(this.trainer)
      .subscribe(
        () => {
          console.log('Trainer updated successfully');
          Swal.fire({
            title: 'Success',
            text: 'Trainer updated successfully',
            icon: 'success'
          })
        },
        (error) => {
          console.error('Error updating trainer:', error);
          Swal.fire({
            title: 'Error',
            text: 'There was an error updating the trainer. Please try again.',
            icon: 'error'
          });
        }
      );
  }

  resetForm() {
    this.trainer = new Trainer();
    this.trainerName = null;
    this.confirmpassword = this.trainer.pass;
  }

  containsNumber(value: string): boolean {
    return /\d/.test(value);
}
containsSpecialSymbol(password: string): boolean {
  const specialSymbols = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
  return specialSymbols.test(password);
}
containsUppercaseLetter(password: string): boolean {
  const uppercaseRegex = /[A-Z]/;
  return uppercaseRegex.test(password);
}



}