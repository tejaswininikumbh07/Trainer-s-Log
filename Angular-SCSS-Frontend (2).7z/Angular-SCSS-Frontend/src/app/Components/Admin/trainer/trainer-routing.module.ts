import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TrainerComponent } from './trainer/trainer.component';
import { AddTrainerComponent } from './add-trainer/add-trainer.component';
import { DeleteTrainerComponent } from './delete-trainer/delete-trainer.component';
import { UpdateTrainerComponent } from './update-trainer/update-trainer.component';
import { ViewTrainerComponent } from './view-trainer/view-trainer.component';

const routes: Routes = [
  {path: 'add',component: AddTrainerComponent},
  {path: 'delete', component: DeleteTrainerComponent},
  {path: 'update', component: UpdateTrainerComponent},
  {path: 'view', component: ViewTrainerComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TrainerRoutingModule { }
