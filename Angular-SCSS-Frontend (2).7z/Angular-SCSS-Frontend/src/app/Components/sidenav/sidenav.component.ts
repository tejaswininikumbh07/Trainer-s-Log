import { animate, keyframes, style, transition, trigger } from '@angular/animations';
import { Component, Output, EventEmitter, OnInit, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { fadeInOut, INavbarData } from './helper';
import { LoginData } from './nav-data';
import { NavDataService } from '../../Services/nav-data-service.service';
import { LoginService } from '../../Services/login.service';
import { User } from '../../Model/user';

interface SideNavToggle {
  screenWidth: number;
  collapsed: boolean;
}

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss'],
  animations: [
    fadeInOut,
    trigger('rotate', [
      transition(':enter', [
        animate('1000ms', 
          keyframes([
            style({transform: 'rotate(0deg)', offset: '0'}),
            style({transform: 'rotate(2turn)', offset: '1'})
          ])
        )
      ])
    ])
  ]
})
export class SidenavComponent implements OnInit {
  //navData: INavbarData[] = LoginData;
  user: User = new User();

  constructor(private navDataService: NavDataService, public router: Router, private logoutService: LoginService) {}

  ngOnInit(): void {
    this.navDataService.navData$.subscribe(({ data, title, logo }) => {
      this.navData = data;
      this.titel = title;
      this.logo = logo;
      this.screenWidth = window.innerWidth;
    });
  }

  @Output() onToggleSideNav: EventEmitter<SideNavToggle> = new EventEmitter();
  collapsed = false;
  screenWidth = 0;
  multiple: boolean = false;
  navData = LoginData;
  logo="fal fa-times close-icon";
  titel= 'Home'
  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.screenWidth = window.innerWidth;
    if(this.screenWidth <= 768 ) {
      this.collapsed = false;
      this.onToggleSideNav.emit({collapsed: this.collapsed, screenWidth: this.screenWidth});
    }
  }
  logout() {
    // Call the logout method from the login service
    this.logoutService.logout(this.user).subscribe(
        response => {
        // Handle successful logout response
        console.log("Logged out successfully", response);
        // Perform any additional actions after logout
      },
      error => {
        // Handle error response if necessary
        console.error("Logout error", error);
      }
    );
  }
  
  isExternalLink(data: INavbarData): boolean {
    return (data.icon === 'fa-brands fa-github' ||
            data.icon === 'fa-brands fa-facebook' ||
            data.icon === 'fa-brands fa-instagram' ||
            data.icon === 'fa-solid fa-envelope' ||
            data.icon === 'fa-brands fa-linkedin') &&
           (data.label === 'github' ||
            data.label === 'Facebook' ||
            data.label === 'Instagram' ||
            data.label === 'Gmail' ||
            data.label === 'LinkedIn');
}
 

  toggleCollapse(): void {
    this.collapsed = !this.collapsed;
    this.onToggleSideNav.emit({collapsed: this.collapsed, screenWidth: this.screenWidth});
  }

  closeSidenav(): void {
    this.collapsed = false;
    this.onToggleSideNav.emit({collapsed: this.collapsed, screenWidth: this.screenWidth});
  }

  handleClick(item: INavbarData): void {
    this.shrinkItems(item);
    item.expanded = !item.expanded
  }

  getActiveClass(data: INavbarData): string {
    return this.router.url.includes(data.routeLink) ? 'active' : '';
  }

  shrinkItems(item: INavbarData): void {
    if (!this.multiple) {
      for(let modelItem of this.navData) {
        if (item !== modelItem && modelItem.expanded) {
          modelItem.expanded = false;
        }
      }
    }
  }
}
