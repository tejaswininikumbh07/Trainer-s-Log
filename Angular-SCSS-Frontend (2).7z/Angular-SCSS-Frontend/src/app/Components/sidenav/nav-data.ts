import { RouterLink } from "@angular/router";
import { INavbarData } from "./helper";
export const LoginData: INavbarData[] = [
  
    {
        routeLink: '/git',
        icon: 'fa-brands fa-github',
        label: 'github',
    },
    {
        routeLink: '/fb',//'https://www.facebook.com/profile.php?id=100080110899706&mibextid=ZbWKwL',
        icon: 'fa-brands fa-facebook',
        label: 'Facebook',
    },
    {
        routeLink :'/insta',
        icon: 'fa-brands fa-instagram',
        label: 'Instagram',
    },
    {
        routeLink:'linkedin',//'https://in.linkedin.com/in/suyog-awate-15494123b?trk=public_profile_samename-profile',
        icon: 'fa-brands fa-linkedin',
        label: 'LinkedIn',
    },
    {
        routeLink: '/about',
        icon: 'fa-solid fa-info',
        label: 'About',
    },
    {
        routeLink: 'login',
        icon: 'fa-solid fa-right-to-bracket',
        label: 'Login',
    },
];
export const AdminData: INavbarData[] = [
    {
        routeLink: 'admin-dash',
        icon: 'fa-solid fa-desktop',
        label: 'Dashboard'
    },
    {
        routeLink: 'trainer',
        icon: 'fa-solid fa-users',
        label: 'Trainer',
        items: [
            {
                routeLink: 'trainer/add',  
                label: 'Add New Trainer'

            },
            {
                routeLink: 'trainer/update',
                label: 'Update a Trainer',
            },
            {
                routeLink: 'trainer/delete',   
                label: 'Remove Trainer',
            },
            {
                routeLink: 'trainer/view',               
                label: 'View Trainer',
            }        
        ]
    },
    {
        routeLink: 'batch',
        icon: 'fa-solid fa-users-viewfinder',
        label: 'Batch',
        items: [
            {
                routeLink: 'batch/add',
                label: 'Create Batch'
            },
            {
                routeLink: 'batch/update',   
                label: 'Update Batch'
            },
            {
                routeLink: 'batch/delete',
                label: 'Drop a Batch'
            },
            {
                routeLink: 'batch/view',
                label: 'View Batch'
            }
        ]
    },
    {
        routeLink: 'profile',
        icon: 'fa-solid fa-user',
        label: 'Profile',
        items: [
            {
                routeLink: 'profile/view', 
                label: 'View Profile'
            },
            {
                routeLink: 'profile/customize',
                label: 'Customize'
            }
        ]
    },
    {
        routeLink: 'login',
        
        icon: 'fa-solid fa-right-from-bracket',
        label: 'Logout'
    },
];
export const TrainerData: INavbarData[] = [
    {
        routeLink: 'trainer-dash',
        icon: 'fa-solid fa-desktop',
        label: 'Dashboard'
    },
    {
        routeLink: 'startbatch',
        icon: 'fa-solid fa-pen-to-square',
        label: 'Batch',
    },
    {
        routeLink: 'logout',
        icon: 'fa-solid fa-right-from-bracket',
        label: 'Logout'
        
    },
];