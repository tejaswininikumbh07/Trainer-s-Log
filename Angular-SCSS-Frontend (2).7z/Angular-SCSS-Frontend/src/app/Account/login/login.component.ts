import { Component, OnInit } from '@angular/core';
import { User } from '../../Model/user';
import { LoginService } from '../../Services/login.service';
import { Router } from '@angular/router';
import { NavDataService } from '../../Services/nav-data-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  passwordVisible: boolean = false;
  accountType: string = "Login";
  email: string = "";
  password: string = "";
  role: string ="";
  user: User = new User();

  constructor(
    private loginService: LoginService,
    private route: Router,
    private navDataService: NavDataService
  ) {
    this.navDataService.updateLoginNavData();
  }

  ngOnInit(): void {
    this.togglePasswordVisibility();
    this.email = '';
    this.password = '';
    this.accountType = 'Login';
    localStorage.clear();
  }
  
  toggleAccountType() {
    this.accountType = this.accountType === "Admin" ? "Trainer" : "Admin";
  }

  login() {
    if (this.accountType === 'Login') {
      alert('Choose Your Account Type');
    } else {
      const user = {
        email: this.email,
        pass: this.password,
        role: this.accountType,
        name: ""
      };

      this.loginService.login(user).subscribe(
        (res: any) => {
          if (res === null) {
            alert('Email or password is wrong');
            this.ngOnInit();
          } else {
            console.log('Login successful');
            if (res.role === 'Trainer') {
              this.route.navigate(['trainer-dash']);
              sessionStorage.setItem('currentUser', JSON.stringify(res));
            } else {
              this.route.navigate(['admin-dash']);
              sessionStorage.setItem('currentUser', JSON.stringify(res));
            }
          }
        },
        err => {
          console.error('Login failed:', err);
          alert('Login failed. Please try again.');
          this.ngOnInit();
        }
      );
    }
  }

  togglePasswordVisibility(): void {
    this.passwordVisible = !this.passwordVisible;
    document.addEventListener('DOMContentLoaded', () => {
      const passIcon = document.querySelector('#PassIcon') as HTMLElement;
      const inputField = document.querySelector('#Password') as HTMLInputElement;
      if (inputField !== null) {
        passIcon?.addEventListener('click', () => {
          inputField.type = inputField.type === 'password' ? 'text' : 'password';
        });
      } else {
        console.error("Password input field not found");
      }
    });
  }
}
