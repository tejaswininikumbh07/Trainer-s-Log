import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../Services/login.service';
import { Router } from '@angular/router';
import { User } from '../../Model/user';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.scss']
})
export class LogoutComponent implements OnInit {
  user: User = new User();

  constructor(private loginService: LoginService, private router: Router) {}

  ngOnInit() {
    const userData = sessionStorage.getItem('currentUser');
    if (userData !== null) {
      this.user = JSON.parse(userData);
    }
    
    this.logout();
  }

  logout() {
    this.loginService.logout(this.user).subscribe(
      response => {
        console.log("Logged out successfully", response);
        console.log(this.user)
        // Redirect to the login page after logout
        this.router.navigate(['login']);
      },
      error => {
        console.error("Logout error", error);
      }
    );
  }
}
