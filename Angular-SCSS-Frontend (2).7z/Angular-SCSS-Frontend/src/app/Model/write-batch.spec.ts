import { WriteBatch } from './write-batch';

describe('WriteBatch', () => {
  it('should create an instance', () => {
    expect(new WriteBatch()).toBeTruthy();
  });
});
