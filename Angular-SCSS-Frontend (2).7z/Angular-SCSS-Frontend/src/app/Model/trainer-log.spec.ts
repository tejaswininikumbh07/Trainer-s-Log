import { TrainerLog } from './trainer-log';

describe('TrainerLog', () => {
  it('should create an instance', () => {
    expect(new TrainerLog()).toBeTruthy();
  });
});
