export class Batch {
    id!: number;
    code!:string;
    name!: string;
    trainer!: string;
    total!: number;
    males!: number;
    females!: number;
    status!: string;
    startDate!: Date;
    endDate!: Date;
    choice!: string;
}
