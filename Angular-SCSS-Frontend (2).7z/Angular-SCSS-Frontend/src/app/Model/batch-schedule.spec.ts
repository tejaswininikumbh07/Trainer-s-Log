import { BatchSchedule } from './batch-schedule';

describe('BatchSchedule', () => {
  it('should create an instance', () => {
    expect(new BatchSchedule()).toBeTruthy();
  });
});
