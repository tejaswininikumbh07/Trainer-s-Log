export class Admin {
  id!: number;
  name!: string;
  email!: string;
  gender:String | undefined;
  address!: string;
  phone!: string;
  dob!: string;
  age!: number;
  bloodGroup!: string;
  medicalInfo!: string;
  education!: string;
  designation!: string;
  pass!: string;
  city!: string;
  state!: string;
  country!: string;
}
