export class TrainerLog {
    id!: number;
    loginTime!: string;
    logoutTime!: string;
    loginDate!: Date;
    trainerName!: string;
}
