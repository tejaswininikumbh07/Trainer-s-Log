import { Calendar } from './calendar';

describe('Calendar', () => {
  it('should create an instance', () => {
    expect(new Calendar()).toBeTruthy();
  });
});
