export class Trainer {
    id!: number;
    name!: string;
    email!: string;
    address!: string;
    phone!: string;
    dob!: string;
    age!: number;
    gender!: string;
    bloodGroup!: string;
    medicalInfo!: string;
    education!: string;
    specification!: string;
    batch!: string;
    city!: string;
    state!: string;
    country!:string;
    pass!: string;
    choice!: string;
}
