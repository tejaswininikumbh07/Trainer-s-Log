export class WriteBatch {
        name!: string;
        code!: string;
        trainer!: string;
        topic!: string;
        studytools!: string;
        homework!: string;
        activities!: string;
        startTime!: string;
        presents!: number;
        absents!: number;
}
