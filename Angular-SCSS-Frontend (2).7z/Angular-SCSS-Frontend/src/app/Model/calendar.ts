export class Calendar {
    batchCode!: string;
    batchName!: string;
    topic!: string;
    homework!: string;
    presentStudents!: string;
    startTime!: string;
    endTime!: string;
}
