import { Batch } from './batch';

describe('Batch', () => {
  it('should create an instance', () => {
    expect(new Batch()).toBeTruthy();
  });
});
