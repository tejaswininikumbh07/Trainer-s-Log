export class BatchSchedule {
    id!: number;
    name!: string;
    code!: string;
    trainer!: string;
    date!: Date;
    topic!: string;
    studytools!: string;
    homework!: string;
    activities!: string;
    startTime!: string; // Assuming LocalTime is stored as string HH:mm:ss
    endTime!: string; // Assuming LocalTime is stored as string HH:mm:ss
    presents!: number;
    absents!: number;
}
