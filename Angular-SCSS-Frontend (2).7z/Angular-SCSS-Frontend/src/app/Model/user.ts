export class User {
    email: String=" ";
    pass : string = '';
    role : string = '';
    name: string ='';

}

