import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Calendar } from '../Model/calendar';
import { Trainer } from '../Model/trainer';
import { Batch } from '../Model/batch';
import { Admin } from '../Model/admin';
import { BatchSchedule } from '../Model/batch-schedule';
import { TrainerLog } from '../Model/trainer-log';

@Injectable({
  providedIn: 'root'
})
export class BackEndService {
  getTrainerDetails(TrainerID: any) {
    throw new Error('Method not implemented.');
  }
  
  
  private calUrl = "http://localhost:8080/batch/search/";
  private traUrl = "http://localhost:8080/trainer/search/";
  private wbUrl = "http://localhost:8080/batch/write";
  private prourl = "http://localhost:8080/trainer/search/";
  private Staturl = "http://localhost:8080/batch/stats/";
  private allTrainersURL = "http://localhost:8080/trainer/all";
  private allBatchesURL ="http://localhost:8080/batch/all";
  private adminUrl ="http://localhost:8080/admin/"
  private updateAdminUrl ="http://localhost:8080/admin/update";
  private AddBatchesURL ="http://localhost:8080/batch/create";
  private UpdateBatchUrl = "http://localhost:8080/batch/update";
  private ViewBatchLogs = "http://localhost:8080/batch/view/all";
  private ViewBatchALogs = "http://localhost:8080/batch/view/";
  private downlaodBatchALogs ="http://localhost:8080/batch/download/";
  private deleteBatchUrl ="http://localhost:8080/batch/delete/";
  private findBatchUrl ="http://localhost:8080/batch/find/";
  private createtrainerUrl = "http://localhost:8080/trainer/create";
  private updateTrainerUrl = "http://localhost:8080/trainer/update";
  private getTrainerLogsUrl = "http://localhost:8080/trainer/alllogs";
  private getATrainerLogUrl ="http://localhost:8080/trainer/log/";
  private getFileTrainerLogUrl ="http://localhost:8080/trainer/export/";
  private deleteTrainerUrl ="http://localhost:8080/trainer/delete/";

  constructor(private http : HttpClient) {
   }

  getBatchSchedule(date: string, trainerName: string): Observable<Calendar[]> {
    const searchUrl = `${this.calUrl}${trainerName}/${date}`;
    return this.http.get<Calendar[]>(searchUrl);
  }

  getTrainer(trainerEmail: string): Observable<Trainer> {
    const searchUrl = `${this.traUrl}${trainerEmail}`;
    return this.http.get<Trainer>(searchUrl);
  } 

  writeBatch(batch: any): Observable<any> {
    return this.http.post<any>(this.wbUrl, batch);
  }
  
  getProfile(email: string): Observable<Trainer> {
    return this.http.get<Trainer>(`${this.prourl}${email}`);
  }

  getBatchStats(trainerName: string): Observable<any> {
    return this.http.get(`${this.Staturl}${trainerName}`);
  }

  getAllTrainers(): Observable<Trainer[]> {
    return this.http.get<Trainer[]>(this.allTrainersURL);
  }

  getAllBatches(): Observable<Batch[]> {
    return this.http.get<Batch[]>(this.allBatchesURL);
  }

  getAdmin(email: string): Observable<Admin> {
    return this.http.get<Admin>(`${this.adminUrl}${email}`);
  }

  updateAdmin(admin: Admin): Observable<Admin> {
    return this.http.put<Admin>(`${this.updateAdminUrl}`, admin);
  }

  createBatch(batch: Batch): Observable<Batch>{
    return this.http.post<Batch>(`${this.AddBatchesURL}`, batch)

  }
  updateBatch( batch: Batch): Observable<Batch>{
    return this.http.put<Batch>(`${this.UpdateBatchUrl}`, batch)
  }
  getBatchLogs(): Observable<Batch>{
    return this.http.get<Batch>(`${this.ViewBatchLogs}`)
  }
  getBatchLog(batchCode: string, batchName: string, fromDate: string, toDate: string): Observable<BatchSchedule[]> {
    return this.http.get<BatchSchedule[]>(`${this.ViewBatchALogs}${batchCode}/${batchName}?fromDate=${fromDate}&toDate=${toDate}`);
  }
  getBatchFile(batchCode: string, batchName: string, fromDate: string, toDate: string): Observable<Blob> {
    const url = `${this.downlaodBatchALogs}${batchCode}/${batchName}?fromDate=${fromDate}&toDate=${toDate}`;
    return this.http.get<Blob>(url, { responseType: 'blob' as 'json' });
}
deleteBatch(BatchID: number) : Observable<any> {
  return this.http.delete(`${this.deleteBatchUrl}${BatchID}`, { responseType: 'text' });
}
searchBatchByCode(BatchCode: string): Observable<Batch> {
  return this.http.get<Batch>(`${this.findBatchUrl}${BatchCode}`);
}
createTrainer(trainer: Trainer): Observable<Trainer>{
  return this.http.post<Trainer>(`${this.createtrainerUrl}`, trainer)

}
updateTrainerDetails(trainer: Trainer): Observable<Trainer>{
return this.http.put<Trainer>(`${this.updateTrainerUrl}`, trainer)
}

getTrainerLogs(): Observable<TrainerLog>{
return this.http.get<TrainerLog>(`${this.getTrainerLogsUrl}`)
}
getLog(Name: string, fromDate: string, toDate: string): Observable<TrainerLog>{
return this.http.get<TrainerLog>(`${this.getATrainerLogUrl}${Name}?fromDate=${fromDate}&toDate=${toDate}`)
}
getTrainerFile(Name: string, fromDate: string, toDate: string): Observable<Blob> {
  const url = `${this.getFileTrainerLogUrl}${Name}?fromDate=${fromDate}&toDate=${toDate}`;
  return this.http.get<Blob>(url, { responseType: 'blob' as 'json' });
}
deleteTrainer(id: number):Observable<any> {
  return this.http.delete(`${this.deleteTrainerUrl}${id}`, { responseType: 'text' });}
}
