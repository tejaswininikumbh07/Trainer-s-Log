import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { INavbarData } from '../Components/sidenav/helper';
import { AdminData, LoginData } from '../Components/sidenav/nav-data';
import { TrainerData } from '../Components/sidenav/nav-data';

@Injectable({
  providedIn: 'root'
})
export class NavDataService {
  tilelAdmin: string = 'Admin';
  titelTrainer: string = 'Trainer';
  titelHome: string = 'Home';
  private _navData: BehaviorSubject<{ data: INavbarData[], title: string, logo: string }> = new BehaviorSubject<{ data: INavbarData[], title: string, logo: string }>({ data: [], title: '', logo: '' }); // Provide initial value as empty array

  constructor() {
    // Set initial nav data
    this.updateNavData([], '', '');
  }

  get navData$() {
    return this._navData.asObservable();
  }

  updateNavData(data: INavbarData[], title: string, logo: string): void {
    // Pass title and logo values along with data
    this._navData.next({ data, title, logo });
  }
  updateLoginNavData(): void {
    this.updateNavData(LoginData, this.titelHome, 'fa-solid fa-house');
  }
  updateAdminNavData(): void {
    this.updateNavData(AdminData, this.tilelAdmin, 'fa-solid fa-user-tie');
  }

  updateTrainerNavData(): void {
    this.updateNavData(TrainerData, this.titelTrainer, 'fa-solid fa-chalkboard-user');
  }
}
