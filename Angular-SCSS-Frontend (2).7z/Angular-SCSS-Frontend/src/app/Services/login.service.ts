import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../Model/user';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  inUrl: string='';
  outUrl: string='';

  constructor(private http : HttpClient) {
    this.inUrl="http://localhost:8080/login";
    this.outUrl="http://localhost:8080/logout";
   }

   login(user : User) : Observable<any> {
    return this.http.post<any>(this.inUrl,user);
  }
  logout(user: User) : Observable<any> {
    return this.http.post<any>(this.outUrl,user);
  }

}
