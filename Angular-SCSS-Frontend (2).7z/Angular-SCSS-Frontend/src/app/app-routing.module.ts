import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminDashboardComponent } from './Components/Admin/admin-dashboard/admin-dashboard.component';

import { WelcomePageComponent } from './Components/welcome-page/welcome-page.component';
import { LoginComponent } from './Account/login/login.component';
import { TrainerDashboardComponent } from './Components/Trainer/trainer-dashboard/trainer-dashboard.component';
import { BatchComponent } from './Components/Trainer/batch/batch.component';
import { LogoutComponent } from './Account/logout/logout.component';
import { TrainerProfileComponent } from './Components/Trainer/trainer-profile/trainer-profile.component';
import { InstagramComponent } from './Components/WebPages/instagram/instagram.component';
import { FacebookComponent } from './Components/WebPages/facebook/facebook.component';
import { GmailComponent } from './Components/WebPages/gmail/gmail.component';
import { AboutComponent } from './Components/WebPages/about/about.component';
import { GithubComponent } from './Components/WebPages/github/github.component';
import { LinkedinComponent } from './Components/WebPages/linkedin/linkedin.component';

const routes: Routes = [
  {path: '', component: WelcomePageComponent},
  {path: 'login',component: LoginComponent},
  {path: 'logout', component: LogoutComponent},
  {path: 'admin-dash', component: AdminDashboardComponent},
  {path:'',redirectTo:'login',pathMatch:'full'},
  {
    path: 'trainer',
    loadChildren: () => import('./Components/Admin/trainer/trainer.module').then(m => m.TrainerModule)
  },
  {
    path: 'batch',
    loadChildren: () => import('./Components/Admin/batch/batch/batch.module').then(m => m.BatchModule)
  },
  {
    path: 'profile',
    loadChildren: () => import('./Components/Admin/profile/profile/profile.module').then(m => m.ProfileModule)
  },
  //{path: 'logout', component: logincomponent}
  
  {path: 'trainer-dash', component :TrainerDashboardComponent},
  {path: 'startbatch',component: BatchComponent},
  {path: 'myprofile', component: TrainerProfileComponent},
  {path: 'insta', component: InstagramComponent},
  {path: 'fb', component: FacebookComponent},
  {path: 'gmail', component: GmailComponent},
  {path: 'about', component: AboutComponent},
  {path: 'git', component: GithubComponent},
  {path: 'linkedin', component:LinkedinComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
